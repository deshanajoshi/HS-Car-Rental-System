import { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Calendar, CreditCard, Download, XCircle, Clock, CheckCircle, Car, FileText } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, formatDateTime } from '../lib/utils';

export default function Dashboard() {
  const { state, updateBooking, addNotification } = useApp();
  const navigate = useNavigate();
  const user = state.currentUser;
  const [activeTab, setActiveTab] = useState<'bookings' | 'payments' | 'profile'>('bookings');

  useEffect(() => {
    if (!user) navigate('/login');
  }, [user, navigate]);

  if (!user) return null;

  const userBookings = state.bookings
    .filter((b) => b.userId === user.id || b.email === user.email)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const active = userBookings.filter((b) => ['Approved', 'Active'].includes(b.bookingStatus));
  const completed = userBookings.filter((b) => b.bookingStatus === 'Completed');
  const cancelled = userBookings.filter((b) => b.bookingStatus === 'Cancelled');
  const pending = userBookings.filter((b) => b.bookingStatus === 'Pending');

  const handleCancelRequest = (bookingId: string) => {
    if (!confirm('Are you sure you want to request cancellation?')) return;
    updateBooking(bookingId, { bookingStatus: 'Cancelled' });
    addNotification({
      type: 'booking',
      title: 'Cancellation Request',
      message: `User requested cancellation of ${bookingId}`,
      read: false,
    });
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">My <span className="gold-text">Dashboard</span></h1>
            <p className="text-gray-400">Welcome back, {user.fullName}</p>
          </div>
          <Link to="/profile" className="btn-outline flex items-center gap-2"><User size={16} /> Edit Profile</Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard icon={Clock} label="Pending" value={pending.length} color="text-yellow-400" />
          <StatCard icon={CheckCircle} label="Active" value={active.length} color="text-green-400" />
          <StatCard icon={Car} label="Completed" value={completed.length} color="text-[var(--primary)]" />
          <StatCard icon={XCircle} label="Cancelled" value={cancelled.length} color="text-red-400" />
        </div>

        {/* Tabs */}
        <div className="flex gap-4 border-b border-[var(--primary)]/20 mb-6">
          {(['bookings', 'payments', 'profile'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-3 text-sm font-medium capitalize ${activeTab === tab ? 'text-[var(--primary)] border-b-2 border-[var(--primary)]' : 'text-gray-400 hover:text-white'}`}
            >
              {tab}
            </button>
          ))}
        </div>

        {activeTab === 'bookings' && (
          <div className="space-y-4">
            {userBookings.length === 0 ? (
              <div className="luxury-card p-10 rounded-xl text-center">
                <p className="text-gray-400 mb-4">No bookings yet.</p>
                <Link to="/cars" className="btn-primary">Browse Cars</Link>
              </div>
            ) : (
              userBookings.map((booking) => {
                const car = state.cars.find((c) => c.id === booking.carId);
                if (!car) return null;
                return (
                  <motion.div key={booking.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="luxury-card p-5 rounded-xl">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="flex gap-4">
                        <img src={car.images[0]} alt={car.name} className="w-24 h-16 object-cover rounded-lg" />
                        <div>
                          <h3 className="text-white font-semibold">{car.name}</h3>
                          <p className="text-gray-400 text-sm">{booking.id}</p>
                          <p className="text-gray-400 text-sm">{formatDateTime(booking.pickupDate, booking.pickupTime)} → {formatDateTime(booking.returnDate, booking.returnTime)}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-[var(--primary)] font-bold">{formatCurrency(booking.totalAmount)}</p>
                        <p className={`text-xs font-semibold ${booking.bookingStatus === 'Approved' || booking.bookingStatus === 'Active' ? 'text-green-400' : booking.bookingStatus === 'Cancelled' ? 'text-red-400' : 'text-yellow-400'}`}>
                          {booking.bookingStatus}
                        </p>
                        <div className="flex gap-2 mt-2 justify-end">
                          <Link to={`/confirmation/${booking.id}`} className="text-xs text-[var(--primary)] hover:underline flex items-center gap-1"><FileText size={12} /> Receipt</Link>
                          {['Pending', 'Approved'].includes(booking.bookingStatus) && (
                            <button onClick={() => handleCancelRequest(booking.id)} className="text-xs text-red-400 hover:underline flex items-center gap-1"><XCircle size={12} /> Cancel</button>
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>
        )}

        {activeTab === 'payments' && (
          <div className="space-y-4">
            {userBookings.length === 0 ? (
              <p className="text-gray-400 text-center py-10">No payment history.</p>
            ) : (
              userBookings.map((booking) => {
                const car = state.cars.find((c) => c.id === booking.carId);
                return (
                  <div key={booking.id} className="luxury-card p-5 rounded-xl flex justify-between items-center">
                    <div>
                      <p className="text-white font-semibold">{car?.name}</p>
                      <p className="text-gray-400 text-sm">{booking.id} • {booking.paymentMethod.toUpperCase()}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-[var(--primary)] font-bold">{formatCurrency(booking.totalAmount)}</p>
                      <p className={`text-xs font-semibold ${booking.paymentStatus === 'Paid' ? 'text-green-400' : 'text-yellow-400'}`}>{booking.paymentStatus}</p>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="luxury-card p-6 rounded-xl">
            <h3 className="text-white font-semibold mb-4">Profile Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <p className="text-gray-400">Name: <span className="text-white">{user.fullName}</span></p>
              <p className="text-gray-400">Email: <span className="text-white">{user.email}</span></p>
              <p className="text-gray-400">Mobile: <span className="text-white">{user.mobile}</span></p>
              <p className="text-gray-400">Address: <span className="text-white">{user.address}, {user.city}, {user.state} - {user.pincode}</span></p>
            </div>
            <Link to="/profile" className="btn-primary mt-6 inline-block text-sm">Edit Profile</Link>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }: { icon: typeof User; label: string; value: number; color: string }) {
  return (
    <div className="luxury-card p-5 rounded-xl text-center">
      <Icon size={24} className={`mx-auto mb-2 ${color}`} />
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-gray-400 text-sm">{label}</p>
    </div>
  );
}
