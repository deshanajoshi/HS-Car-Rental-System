import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Star, Fuel, Settings, Users, CheckCircle, Calendar, Shield, Gauge, Car } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, classNames } from '../lib/utils';

export default function CarDetails() {
  const { id } = useParams<{ id: string }>();
  const { state } = useApp();
  const navigate = useNavigate();
  const car = state.cars.find((c) => c.id === id);
  const [activeImage, setActiveImage] = useState(0);

  if (!car) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Car Not Found</h2>
          <Link to="/cars" className="btn-primary">Browse Cars</Link>
        </div>
      </div>
    );
  }

  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-7xl mx-auto px-4">
        {/* Breadcrumb */}
        <div className="text-sm text-gray-400 mb-6">
          <Link to="/" className="hover:text-[var(--primary)]">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/cars" className="hover:text-[var(--primary)]">Cars</Link>
          <span className="mx-2">/</span>
          <span className="text-[var(--primary)]">{car.name}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Image Gallery */}
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="relative h-80 md:h-[450px] rounded-xl overflow-hidden border border-[var(--primary)]/20 mb-4">
              <img src={car.images[activeImage] || car.images[0]} alt={car.name} className="w-full h-full object-cover" />
              {car.status !== 'available' && (
                <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                  <span className="text-2xl font-bold text-white uppercase tracking-widest border-2 border-white px-6 py-2">{car.status}</span>
                </div>
              )}
            </div>
            <div className="flex gap-3 overflow-x-auto pb-2">
              {car.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImage(idx)}
                  className={classNames(
                    'w-24 h-16 rounded-lg overflow-hidden border-2 flex-shrink-0',
                    activeImage === idx ? 'border-[var(--primary)]' : 'border-transparent'
                  )}
                >
                  <img src={img} alt={`${car.name} ${idx + 1}`} className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </motion.div>

          {/* Details */}
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <div className="flex items-center gap-2 mb-2">
              <span className="badge badge-gold">{car.brand}</span>
              <span className={classNames('badge', car.status === 'available' ? 'badge-green' : 'badge-red')}>{car.status}</span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{car.name}</h1>
            <p className="text-gray-400 mb-4">{car.model} • {car.registrationNo}</p>

            <div className="flex items-center gap-2 mb-6">
              <Star size={20} className="text-[var(--primary)] fill-[var(--primary)]" />
              <span className="text-white font-semibold">{car.rating}</span>
              <span className="text-gray-400">({car.reviewCount} reviews)</span>
            </div>

            <p className="text-gray-300 leading-relaxed mb-6">{car.description}</p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <SpecBox icon={Fuel} label="Fuel Type" value={car.fuelType} />
              <SpecBox icon={Settings} label="Transmission" value={car.transmission} />
              <SpecBox icon={Users} label="Seating" value={`${car.seatingCapacity} Seats`} />
              <SpecBox icon={Gauge} label="Mileage" value="Certified" />
            </div>

            <div className="luxury-card p-5 rounded-xl mb-6">
              <h3 className="text-white font-semibold mb-3">Pricing</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-[#1f1f1f] p-3 rounded-lg text-center">
                  <p className="text-[var(--primary)] font-bold text-xl">{formatCurrency(car.pricePerHour)}</p>
                  <p className="text-gray-400 text-xs">Per Hour</p>
                </div>
                <div className="bg-[#1f1f1f] p-3 rounded-lg text-center">
                  <p className="text-[var(--primary)] font-bold text-xl">{formatCurrency(car.pricePerDay)}</p>
                  <p className="text-gray-400 text-xs">Per Day</p>
                </div>
                <div className="bg-[#1f1f1f] p-3 rounded-lg text-center">
                  <p className="text-[var(--primary)] font-bold text-xl">{formatCurrency(car.securityDeposit)}</p>
                  <p className="text-gray-400 text-xs">Security Deposit</p>
                </div>
              </div>
            </div>

            <div className="luxury-card p-5 rounded-xl mb-6">
              <h3 className="text-white font-semibold mb-3">Features</h3>
              <div className="grid grid-cols-2 gap-2">
                {car.features.map((feature, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-gray-300 text-sm">
                    <CheckCircle size={14} className="text-[var(--primary)]" />
                    {feature}
                  </div>
                ))}
              </div>
            </div>

            <div className="luxury-card p-5 rounded-xl mb-6">
              <h3 className="text-white font-semibold mb-3 flex items-center gap-2"><Calendar size={18} className="text-[var(--primary)]" /> Availability Calendar</h3>
              <p className="text-gray-400 text-sm mb-3">Check available dates. Select your pickup and return dates in the booking form.</p>
              <input type="date" min={today} className="form-input w-auto" />
            </div>

            <button
              onClick={() => navigate(`/booking/${car.id}`)}
              disabled={car.status !== 'available'}
              className={classNames(
                'w-full py-4 rounded-lg font-bold text-lg',
                car.status === 'available' ? 'btn-primary' : 'bg-gray-700 text-gray-400 cursor-not-allowed'
              )}
            >
              {car.status === 'available' ? 'Book Now' : 'Currently Unavailable'}
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function SpecBox({ icon: Icon, label, value }: { icon: typeof Car; label: string; value: string }) {
  return (
    <div className="luxury-card p-4 rounded-lg text-center">
      <Icon size={22} className="text-[var(--primary)] mx-auto mb-2" />
      <p className="text-gray-400 text-xs">{label}</p>
      <p className="text-white font-medium text-sm">{value}</p>
    </div>
  );
}
