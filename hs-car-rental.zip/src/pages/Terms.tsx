import { useApp } from '../lib/context';

export default function Terms() {
  const { state } = useApp();
  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center">Terms & <span className="gold-text">Conditions</span></h1>
        <div className="luxury-card p-8 rounded-2xl">
          <div className="text-gray-300 leading-relaxed whitespace-pre-line">{state.cms.termsContent}</div>
          <div className="mt-8 space-y-4 text-gray-300 text-sm">
            <h3 className="text-white font-semibold text-lg">Rental Terms</h3>
            <ul className="list-disc list-inside space-y-2">
              <li>Renter must hold a valid Indian driving license.</li>
              <li>Minimum age for renting is 21 years.</li>
              <li>Fuel policy: same-to-same or as per rental agreement.</li>
              <li>Late returns may attract additional hourly charges.</li>
              <li>Any damage caused by negligence is the renter's financial responsibility.</li>
              <li>Traffic violations and fines during rental period are borne by the renter.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
