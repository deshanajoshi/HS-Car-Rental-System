import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Calendar, Clock, User, CreditCard, Shield, AlertCircle, CheckCircle } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, calculateRental, generateBookingId, validateAadhaar, validateMobile, validateEmail, sanitizeInput } from '../lib/utils';

export default function Booking() {
  const { carId } = useParams<{ carId: string }>();
  const { state, addBooking, addNotification } = useApp();
  const currentUser = state.currentUser;
  const navigate = useNavigate();
  const car = state.cars.find((c) => c.id === carId);

  const [form, setForm] = useState({
    fullName: currentUser?.fullName || '',
    email: currentUser?.email || '',
    mobile: currentUser?.mobile || '',
    address: currentUser?.address || '',
    city: currentUser?.city || '',
    state: currentUser?.state || '',
    pincode: currentUser?.pincode || '',
    pickupDate: '',
    pickupTime: '10:00',
    returnDate: '',
    returnTime: '10:00',
    kyc1Name: '',
    kyc1Aadhaar: '',
    kyc1Mobile: '',
    kyc2Name: '',
    kyc2Aadhaar: '',
    kyc2Mobile: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [agreed, setAgreed] = useState(false);

  useEffect(() => {
    if (!car) {
      navigate('/cars');
    }
  }, [car, navigate]);

  if (!car) return null;

  const rental = calculateRental(form.pickupDate, form.pickupTime, form.returnDate, form.returnTime, car.pricePerHour, car.pricePerDay);
  const totalAmount = rental.total;
  const grandTotal = totalAmount + car.securityDeposit;

  const today = new Date().toISOString().split('T')[0];

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: sanitizeInput(value) }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!form.fullName.trim()) newErrors.fullName = 'Full name is required';
    if (!validateEmail(form.email)) newErrors.email = 'Valid email is required';
    if (!validateMobile(form.mobile)) newErrors.mobile = 'Valid 10-digit mobile is required';
    if (!form.address.trim()) newErrors.address = 'Address is required';
    if (!form.city.trim()) newErrors.city = 'City is required';
    if (!form.state.trim()) newErrors.state = 'State is required';
    if (!/^\d{6}$/.test(form.pincode)) newErrors.pincode = 'Valid 6-digit pincode is required';
    if (!form.pickupDate) newErrors.pickupDate = 'Pickup date is required';
    if (!form.pickupTime) newErrors.pickupTime = 'Pickup time is required';
    if (!form.returnDate) newErrors.returnDate = 'Return date is required';
    if (!form.returnTime) newErrors.returnTime = 'Return time is required';

    if (form.pickupDate && form.returnDate) {
      const start = new Date(`${form.pickupDate}T${form.pickupTime}`);
      const end = new Date(`${form.returnDate}T${form.returnTime}`);
      if (end <= start) newErrors.returnDate = 'Return must be after pickup';
    }

    if (!form.kyc1Name.trim()) newErrors.kyc1Name = 'KYC person 1 name is required';
    if (!validateAadhaar(form.kyc1Aadhaar)) newErrors.kyc1Aadhaar = 'Valid 12-digit Aadhaar required';
    if (!validateMobile(form.kyc1Mobile)) newErrors.kyc1Mobile = 'Valid 10-digit mobile required';

    if (!form.kyc2Name.trim()) newErrors.kyc2Name = 'KYC person 2 name is required';
    if (!validateAadhaar(form.kyc2Aadhaar)) newErrors.kyc2Aadhaar = 'Valid 12-digit Aadhaar required';
    if (!validateMobile(form.kyc2Mobile)) newErrors.kyc2Mobile = 'Valid 10-digit mobile required';

    if (!agreed) newErrors.terms = 'You must agree to terms';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const bookingId = generateBookingId();
    const newBooking = addBooking({
      id: bookingId,
      carId: car.id,
      userId: currentUser?.id || null,
      customerName: form.fullName,
      email: form.email,
      mobile: form.mobile,
      address: form.address,
      city: form.city,
      state: form.state,
      pincode: form.pincode,
      pickupDate: form.pickupDate,
      pickupTime: form.pickupTime,
      returnDate: form.returnDate,
      returnTime: form.returnTime,
      hours: rental.hours,
      days: rental.days,
      totalAmount: grandTotal,
      securityDeposit: car.securityDeposit,
      paymentMethod: 'upi',
      paymentStatus: 'Pending',
      bookingStatus: 'Pending',
      kycPersons: [
        { name: form.kyc1Name, aadhaar: form.kyc1Aadhaar, mobile: form.kyc1Mobile },
        { name: form.kyc2Name, aadhaar: form.kyc2Aadhaar, mobile: form.kyc2Mobile },
      ],
    });

    addNotification({
      type: 'booking',
      title: 'New Booking Received',
      message: `Booking ${bookingId} by ${form.fullName} for ${car.name} - ${formatCurrency(grandTotal)}`,
      read: false,
    });

    // Play notification sound
    try {
      const audio = new Audio('https://actions.google.com/sounds/v1/cartoon/pop.ogg');
      audio.play().catch(() => {});
    } catch {}

    navigate(`/payment/${bookingId}`);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-6xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-2">Book Your <span className="gold-text">{car.name}</span></h1>
        <p className="text-gray-400 mb-8">Complete the form below to reserve your car</p>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main form */}
          <div className="lg:col-span-2 space-y-6">
            {/* Customer Details */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="luxury-card p-6 rounded-xl">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><User size={20} className="text-[var(--primary)]" /> Customer Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Input label="Full Name" value={form.fullName} onChange={(v) => handleChange('fullName', v)} error={errors.fullName} />
                <Input label="Email" type="email" value={form.email} onChange={(v) => handleChange('email', v)} error={errors.email} />
                <Input label="Mobile Number" value={form.mobile} onChange={(v) => handleChange('mobile', v.replace(/\D/g, '').slice(0, 10))} error={errors.mobile} />
                <Input label="Address" value={form.address} onChange={(v) => handleChange('address', v)} error={errors.address} />
                <Input label="City" value={form.city} onChange={(v) => handleChange('city', v)} error={errors.city} />
                <Input label="State" value={form.state} onChange={(v) => handleChange('state', v)} error={errors.state} />
                <Input label="Pincode" value={form.pincode} onChange={(v) => handleChange('pincode', v.replace(/\D/g, '').slice(0, 6))} error={errors.pincode} />
              </div>
            </motion.div>

            {/* Rental Dates */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="luxury-card p-6 rounded-xl">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><Calendar size={20} className="text-[var(--primary)]" /> Rental Period</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Pickup Date</label>
                  <input type="date" min={today} value={form.pickupDate} onChange={(e) => handleChange('pickupDate', e.target.value)} className="form-input" />
                  {errors.pickupDate && <p className="text-red-400 text-xs mt-1">{errors.pickupDate}</p>}
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Pickup Time</label>
                  <input type="time" value={form.pickupTime} onChange={(e) => handleChange('pickupTime', e.target.value)} className="form-input" />
                  {errors.pickupTime && <p className="text-red-400 text-xs mt-1">{errors.pickupTime}</p>}
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Return Date</label>
                  <input type="date" min={form.pickupDate || today} value={form.returnDate} onChange={(e) => handleChange('returnDate', e.target.value)} className="form-input" />
                  {errors.returnDate && <p className="text-red-400 text-xs mt-1">{errors.returnDate}</p>}
                </div>
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Return Time</label>
                  <input type="time" value={form.returnTime} onChange={(e) => handleChange('returnTime', e.target.value)} className="form-input" />
                  {errors.returnTime && <p className="text-red-400 text-xs mt-1">{errors.returnTime}</p>}
                </div>
              </div>
            </motion.div>

            {/* KYC Details */}
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }} className="luxury-card p-6 rounded-xl">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><Shield size={20} className="text-[var(--primary)]" /> Mandatory KYC (2 Persons)</h2>
              <div className="bg-[var(--primary)]/10 border border-[var(--primary)]/30 p-3 rounded-lg mb-4 flex items-start gap-2">
                <AlertCircle size={18} className="text-[var(--primary)] mt-0.5 shrink-0" />
                <p className="text-sm text-gray-300">Booking cannot continue without valid KYC. Aadhaar must be 12 digits and mobile must be 10 digits.</p>
              </div>
              <div className="space-y-6">
                <div className="bg-[#1f1f1f] p-4 rounded-lg">
                  <h3 className="text-[var(--primary)] font-semibold mb-3">Person 1</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Input label="Full Name" value={form.kyc1Name} onChange={(v) => handleChange('kyc1Name', v)} error={errors.kyc1Name} />
                    <Input label="Aadhaar Number" value={form.kyc1Aadhaar} onChange={(v) => handleChange('kyc1Aadhaar', v.replace(/\D/g, '').slice(0, 12))} error={errors.kyc1Aadhaar} />
                    <Input label="Mobile Number" value={form.kyc1Mobile} onChange={(v) => handleChange('kyc1Mobile', v.replace(/\D/g, '').slice(0, 10))} error={errors.kyc1Mobile} />
                  </div>
                </div>
                <div className="bg-[#1f1f1f] p-4 rounded-lg">
                  <h3 className="text-[var(--primary)] font-semibold mb-3">Person 2</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Input label="Full Name" value={form.kyc2Name} onChange={(v) => handleChange('kyc2Name', v)} error={errors.kyc2Name} />
                    <Input label="Aadhaar Number" value={form.kyc2Aadhaar} onChange={(v) => handleChange('kyc2Aadhaar', v.replace(/\D/g, '').slice(0, 12))} error={errors.kyc2Aadhaar} />
                    <Input label="Mobile Number" value={form.kyc2Mobile} onChange={(v) => handleChange('kyc2Mobile', v.replace(/\D/g, '').slice(0, 10))} error={errors.kyc2Mobile} />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Summary sidebar */}
          <div className="lg:col-span-1">
            <div className="luxury-card p-6 rounded-xl sticky top-24">
              <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><CreditCard size={20} className="text-[var(--primary)]" /> Booking Summary</h2>
              <div className="flex gap-4 mb-4">
                <img src={car.images[0]} alt={car.name} className="w-24 h-16 object-cover rounded-lg" />
                <div>
                  <p className="text-white font-semibold">{car.name}</p>
                  <p className="text-gray-400 text-xs">{car.transmission} • {car.fuelType}</p>
                </div>
              </div>
              <div className="space-y-3 text-sm border-t border-[var(--primary)]/10 pt-4">
                <div className="flex justify-between text-gray-300">
                  <span>Rental Duration</span>
                  <span>{rental.days > 0 ? `${rental.days} days` : `${rental.hours} hrs`}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Rental Amount</span>
                  <span>{formatCurrency(totalAmount)}</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>Security Deposit</span>
                  <span>{formatCurrency(car.securityDeposit)}</span>
                </div>
                <div className="flex justify-between text-[var(--primary)] font-bold text-lg border-t border-[var(--primary)]/20 pt-3">
                  <span>Total Amount</span>
                  <span>{formatCurrency(grandTotal)}</span>
                </div>
              </div>

              <div className="mt-6 flex items-start gap-2">
                <input type="checkbox" id="terms" checked={agreed} onChange={(e) => setAgreed(e.target.checked)} className="mt-1 accent-[var(--primary)]" />
                <label htmlFor="terms" className="text-xs text-gray-400">I agree to the <Link to="/terms" className="text-[var(--primary)]">Terms & Conditions</Link>, <Link to="/privacy" className="text-[var(--primary)]">Privacy Policy</Link> and <Link to="/refund" className="text-[var(--primary)]">Refund Policy</Link>.</label>
              </div>
              {errors.terms && <p className="text-red-400 text-xs mt-1">{errors.terms}</p>}

              <button type="submit" className="w-full btn-primary mt-6 flex items-center justify-center gap-2">
                <CheckCircle size={18} /> Proceed to Payment
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

function Input({ label, value, onChange, error, type = 'text' }: { label: string; value: string; onChange: (v: string) => void; error?: string; type?: string }) {
  return (
    <div>
      <label className="text-sm text-gray-400 block mb-1">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className="form-input" />
      {error && <p className="text-red-400 text-xs mt-1">{error}</p>}
    </div>
  );
}
