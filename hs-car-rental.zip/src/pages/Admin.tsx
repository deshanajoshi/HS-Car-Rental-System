import { useEffect, useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  LayoutDashboard, Car, Calendar, CreditCard, MessageSquare, Star, Settings,
  Bell, LogOut, Search, Trash2, Edit, CheckCircle, XCircle, Eye, EyeOff,
  Plus, Save, MapPin, Phone, Mail, Upload, X
} from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, formatDateTime, classNames } from '../lib/utils';
import type { Car as CarType, Booking, Review, ContactMessage, User } from '../lib/types';

const tabs = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'cars', label: 'Cars', icon: Car },
  { id: 'bookings', label: 'Bookings', icon: Calendar },
  { id: 'payments', label: 'Payments', icon: CreditCard },
  { id: 'reviews', label: 'Reviews', icon: Star },
  { id: 'contacts', label: 'Messages', icon: MessageSquare },
  { id: 'cms', label: 'CMS', icon: Settings },
  { id: 'website', label: 'Settings', icon: MapPin },
];

export default function Admin() {
  const { state, logout, updateBooking, updateCar, deleteCar, addCar, approveReview, hideReview, deleteReview, deleteContactMessage, updateCms, updateWebsite, markNotificationRead } = useApp();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('dashboard');

  useEffect(() => {
    if (!state.currentUser || state.currentUser.role !== 'admin') {
      navigate('/login');
    }
  }, [state.currentUser, navigate]);

  if (!state.currentUser || state.currentUser.role !== 'admin') return null;

  const stats = {
    totalCars: state.cars.length,
    totalBookings: state.bookings.length,
    revenue: state.bookings.filter((b) => b.paymentStatus === 'Paid').reduce((sum, b) => sum + b.totalAmount, 0),
    pendingPayments: state.bookings.filter((b) => b.paymentStatus === 'Pending').length,
    activeRentals: state.bookings.filter((b) => b.bookingStatus === 'Active').length,
    pendingApprovals: state.bookings.filter((b) => b.bookingStatus === 'Pending').length,
    totalUsers: state.users.filter((u) => u.role === 'user').length,
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a]">
      {/* Admin header */}
      <div className="bg-[#121212] border-b border-[var(--primary)]/20 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <img src={state.cms.logo} alt="logo" className="h-8 w-8" />
            <h1 className="text-lg font-bold text-white">Admin <span className="text-[var(--primary)]">Panel</span></h1>
          </div>
          <div className="flex items-center gap-4">
            <Link to="/" className="text-sm text-gray-400 hover:text-[var(--primary)]">View Site</Link>
            <button onClick={logout} className="text-sm text-gray-400 hover:text-red-400 flex items-center gap-1"><LogOut size={16} /> Logout</button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="luxury-card p-3 rounded-xl sticky top-20">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={classNames(
                    'w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all',
                    activeTab === tab.id ? 'bg-[var(--primary)]/10 text-[var(--primary)]' : 'text-gray-400 hover:bg-[#1f1f1f] hover:text-white'
                  )}
                >
                  <tab.icon size={18} /> {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-4">
            {activeTab === 'dashboard' && <DashboardTab stats={stats} notifications={state.notifications} markRead={markNotificationRead} />}
            {activeTab === 'cars' && <CarsTab cars={state.cars} updateCar={updateCar} deleteCar={deleteCar} addCar={addCar} />}
            {activeTab === 'bookings' && <BookingsTab bookings={state.bookings} cars={state.cars} users={state.users} updateBooking={updateBooking} />}
            {activeTab === 'payments' && <PaymentsTab bookings={state.bookings} cars={state.cars} updateBooking={updateBooking} website={state.website} updateWebsite={updateWebsite} />}
            {activeTab === 'reviews' && <ReviewsTab reviews={state.reviews} approve={approveReview} hide={hideReview} remove={deleteReview} />}
            {activeTab === 'contacts' && <ContactsTab messages={state.contactMessages} remove={deleteContactMessage} />}
            {activeTab === 'cms' && <CmsTab cms={state.cms} updateCms={updateCms} />}
            {activeTab === 'website' && <WebsiteTab website={state.website} updateWebsite={updateWebsite} />}
          </div>
        </div>
      </div>
    </div>
  );
}

function DashboardTab({ stats, notifications, markRead }: { stats: Record<string, number>; notifications: import('../lib/types').Notification[]; markRead: (id: string) => void }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Dashboard</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {Object.entries(stats).map(([key, value]) => (
          <motion.div key={key} whileHover={{ y: -2 }} className="luxury-card p-5 rounded-xl">
            <p className="text-gray-400 text-sm capitalize">{key.replace(/([A-Z])/g, ' $1')}</p>
            <p className="text-2xl font-bold text-[var(--primary)] mt-1">{key === 'revenue' ? formatCurrency(value) : value}</p>
          </motion.div>
        ))}
      </div>

      <div className="luxury-card p-6 rounded-xl">
        <h3 className="text-white font-semibold mb-4 flex items-center gap-2"><Bell size={18} className="text-[var(--primary)]" /> Recent Notifications</h3>
        {notifications.length === 0 ? (
          <p className="text-gray-400 text-sm">No notifications yet.</p>
        ) : (
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {notifications.slice(0, 20).map((n) => (
              <div key={n.id} onClick={() => markRead(n.id)} className={`p-3 rounded-lg bg-[#1f1f1f] cursor-pointer ${n.read ? 'opacity-60' : ''}`}>
                <p className="text-sm font-semibold text-[var(--primary)]">{n.title}</p>
                <p className="text-xs text-gray-300">{n.message}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function CarsTab({ cars, updateCar, deleteCar, addCar }: { cars: CarType[]; updateCar: (id: string, c: Partial<CarType>) => void; deleteCar: (id: string) => void; addCar: (c: Omit<CarType, 'id' | 'rating' | 'reviewCount'>) => void }) {
  const [editing, setEditing] = useState<CarType | null>(null);
  const [showForm, setShowForm] = useState(false);

  const emptyCar: Omit<CarType, 'id' | 'rating' | 'reviewCount'> = {
    name: '', brand: '', model: '', registrationNo: '', fuelType: 'Petrol', transmission: 'Manual', seatingCapacity: 5,
    pricePerHour: 0, pricePerDay: 0, securityDeposit: 0, description: '', features: [], images: [], status: 'available',
    featured: false, popular: false, latest: false,
  };

  const [form, setForm] = useState(emptyCar);

  const openEdit = (car: CarType) => {
    setEditing(car);
    setForm({ ...car });
    setShowForm(true);
  };

  const openAdd = () => {
    setEditing(null);
    setForm(emptyCar);
    setShowForm(true);
  };

  const handleSave = () => {
    if (editing) {
      updateCar(editing.id, form);
    } else {
      addCar(form);
    }
    setShowForm(false);
  };

  const toggleStatus = (car: CarType) => {
    updateCar(car.id, { status: car.status === 'disabled' ? 'available' : 'disabled' as CarType['status'] });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Car Management</h2>
        <button onClick={openAdd} className="btn-primary flex items-center gap-2"><Plus size={18} /> Add Car</button>
      </div>

      {showForm && (
        <div className="luxury-card p-6 rounded-xl space-y-4">
          <h3 className="text-white font-semibold">{editing ? 'Edit Car' : 'Add New Car'}</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="form-input" />
            <input placeholder="Brand" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} className="form-input" />
            <input placeholder="Model" value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} className="form-input" />
            <input placeholder="Registration No" value={form.registrationNo} onChange={(e) => setForm({ ...form, registrationNo: e.target.value })} className="form-input" />
            <select value={form.fuelType} onChange={(e) => setForm({ ...form, fuelType: e.target.value as CarType['fuelType'] })} className="form-input">
              <option>Petrol</option><option>Diesel</option><option>Electric</option><option>Hybrid</option><option>CNG</option>
            </select>
            <select value={form.transmission} onChange={(e) => setForm({ ...form, transmission: e.target.value as CarType['transmission'] })} className="form-input">
              <option>Manual</option><option>Automatic</option>
            </select>
            <input type="number" placeholder="Seating" value={form.seatingCapacity} onChange={(e) => setForm({ ...form, seatingCapacity: Number(e.target.value) })} className="form-input" />
            <input type="number" placeholder="Price/Hour (₹)" value={form.pricePerHour} onChange={(e) => setForm({ ...form, pricePerHour: Number(e.target.value) })} className="form-input" />
            <input type="number" placeholder="Price/Day (₹)" value={form.pricePerDay} onChange={(e) => setForm({ ...form, pricePerDay: Number(e.target.value) })} className="form-input" />
            <input type="number" placeholder="Security Deposit (₹)" value={form.securityDeposit} onChange={(e) => setForm({ ...form, securityDeposit: Number(e.target.value) })} className="form-input" />
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as CarType['status'] })} className="form-input">
              <option value="available">Available</option><option value="rented">Rented</option><option value="maintenance">Maintenance</option><option value="disabled">Disabled</option>
            </select>
          </div>
          <textarea placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="form-input" rows={3} />
          <input placeholder="Features (comma separated)" value={form.features.join(', ')} onChange={(e) => setForm({ ...form, features: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })} className="form-input" />
          <input placeholder="Image URLs (comma separated)" value={form.images.join(', ')} onChange={(e) => setForm({ ...form, images: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })} className="form-input" />
          <div className="flex gap-4">
            <label className="flex items-center gap-2 text-gray-300 text-sm"><input type="checkbox" checked={form.featured} onChange={(e) => setForm({ ...form, featured: e.target.checked })} /> Featured</label>
            <label className="flex items-center gap-2 text-gray-300 text-sm"><input type="checkbox" checked={form.popular} onChange={(e) => setForm({ ...form, popular: e.target.checked })} /> Popular</label>
            <label className="flex items-center gap-2 text-gray-300 text-sm"><input type="checkbox" checked={form.latest} onChange={(e) => setForm({ ...form, latest: e.target.checked })} /> Latest</label>
          </div>
          <div className="flex gap-3">
            <button onClick={handleSave} className="btn-primary flex items-center gap-2"><Save size={16} /> Save</button>
            <button onClick={() => setShowForm(false)} className="btn-outline">Cancel</button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-[#1f1f1f] text-gray-400">
            <tr>
              <th className="p-3">Car</th>
              <th className="p-3">Brand</th>
              <th className="p-3">Price/Day</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {cars.map((car) => (
              <tr key={car.id} className="border-b border-[var(--primary)]/10 hover:bg-[#1f1f1f]/50">
                <td className="p-3 flex items-center gap-2">
                  <img src={car.images[0]} alt={car.name} className="w-10 h-7 object-cover rounded" />
                  <span className="text-white">{car.name}</span>
                </td>
                <td className="p-3 text-gray-300">{car.brand}</td>
                <td className="p-3 text-[var(--primary)]">{formatCurrency(car.pricePerDay)}</td>
                <td className="p-3">
                  <span className={`badge ${car.status === 'available' ? 'badge-green' : 'badge-red'}`}>{car.status}</span>
                </td>
                <td className="p-3">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(car)} className="p-1.5 text-blue-400 hover:bg-blue-400/10 rounded"><Edit size={16} /></button>
                    <button onClick={() => toggleStatus(car)} className="p-1.5 text-yellow-400 hover:bg-yellow-400/10 rounded">{car.status === 'disabled' ? <Eye size={16} /> : <EyeOff size={16} />}</button>
                    <button onClick={() => confirm('Delete this car?') && deleteCar(car.id)} className="p-1.5 text-red-400 hover:bg-red-400/10 rounded"><Trash2 size={16} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function BookingsTab({ bookings, cars, users, updateBooking }: { bookings: Booking[]; cars: CarType[]; users: User[]; updateBooking: (id: string, b: Partial<Booking>) => void }) {
  const [selected, setSelected] = useState<Booking | null>(null);

  const statuses: Booking['bookingStatus'][] = ['Pending', 'Approved', 'Rejected', 'Active', 'Completed', 'Cancelled'];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Booking Management</h2>
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-[#1f1f1f] text-gray-400">
            <tr>
              <th className="p-3">Booking ID</th>
              <th className="p-3">Customer</th>
              <th className="p-3">Car</th>
              <th className="p-3">Amount</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => {
              const car = cars.find((c) => c.id === b.carId);
              return (
                <tr key={b.id} className="border-b border-[var(--primary)]/10 hover:bg-[#1f1f1f]/50">
                  <td className="p-3 text-white font-medium">{b.id}</td>
                  <td className="p-3 text-gray-300">{b.customerName}<br /><span className="text-xs text-gray-500">{b.mobile}</span></td>
                  <td className="p-3 text-gray-300">{car?.name}</td>
                  <td className="p-3 text-[var(--primary)]">{formatCurrency(b.totalAmount)}</td>
                  <td className="p-3"><span className={`badge ${b.bookingStatus === 'Approved' || b.bookingStatus === 'Active' ? 'badge-green' : b.bookingStatus === 'Cancelled' || b.bookingStatus === 'Rejected' ? 'badge-red' : 'badge-yellow'}`}>{b.bookingStatus}</span></td>
                  <td className="p-3">
                    <div className="flex gap-2">
                      <button onClick={() => setSelected(b)} className="p-1.5 text-blue-400 hover:bg-blue-400/10 rounded"><Eye size={16} /></button>
                      <select value={b.bookingStatus} onChange={(e) => updateBooking(b.id, { bookingStatus: e.target.value as Booking['bookingStatus'] })} className="bg-[#1f1f1f] text-white text-xs border border-[var(--primary)]/20 rounded px-2">
                        {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selected && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4" onClick={() => setSelected(null)}>
          <div className="bg-[#121212] border border-[var(--primary)]/30 rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-bold text-white">Booking Details</h3>
              <button onClick={() => setSelected(null)} className="text-gray-400 hover:text-white"><X size={20} /></button>
            </div>
            <div className="space-y-3 text-sm text-gray-300">
              <p><span className="text-gray-500">Booking ID:</span> {selected.id}</p>
              <p><span className="text-gray-500">Customer:</span> {selected.customerName} ({selected.email}, {selected.mobile})</p>
              <p><span className="text-gray-500">Address:</span> {selected.address}, {selected.city}, {selected.state} - {selected.pincode}</p>
              <p><span className="text-gray-500">Pickup:</span> {formatDateTime(selected.pickupDate, selected.pickupTime)}</p>
              <p><span className="text-gray-500">Return:</span> {formatDateTime(selected.returnDate, selected.returnTime)}</p>
              <p><span className="text-gray-500">Amount:</span> {formatCurrency(selected.totalAmount)}</p>
              <div>
                <p className="text-gray-500 mb-1">KYC Persons:</p>
                {selected.kycPersons.map((p, i) => (
                  <p key={i} className="pl-3">{i + 1}. {p.name} • Aadhaar: {p.aadhaar} • Mobile: {p.mobile}</p>
                ))}
              </div>
              {selected.paymentScreenshot && (
                <div>
                  <p className="text-gray-500 mb-1">Payment Screenshot:</p>
                  <img src={selected.paymentScreenshot} alt="Payment" className="w-full max-w-xs rounded border border-[var(--primary)]/20" />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function PaymentsTab({ bookings, cars, updateBooking, website, updateWebsite }: { bookings: Booking[]; cars: CarType[]; updateBooking: (id: string, b: Partial<Booking>) => void; website: import('../lib/types').WebsiteSettings; updateWebsite: (w: Partial<import('../lib/types').WebsiteSettings>) => void }) {
  const [upiId, setUpiId] = useState(website.upiId);
  const [cod, setCod] = useState(website.codEnabled);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Payment Management</h2>

      <div className="luxury-card p-6 rounded-xl space-y-4">
        <h3 className="text-white font-semibold">UPI / QR Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm text-gray-400 block mb-1">UPI ID</label>
            <input value={upiId} onChange={(e) => setUpiId(e.target.value)} className="form-input" />
          </div>
          <div className="flex items-end">
            <label className="flex items-center gap-2 text-gray-300 text-sm"><input type="checkbox" checked={cod} onChange={(e) => setCod(e.target.checked)} /> Enable Cash on Delivery (COD)</label>
          </div>
        </div>
        <button onClick={() => { updateWebsite({ upiId, codEnabled: cod }); alert('Payment settings saved'); }} className="btn-primary">Save Payment Settings</button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="bg-[#1f1f1f] text-gray-400">
            <tr>
              <th className="p-3">Booking ID</th>
              <th className="p-3">Customer</th>
              <th className="p-3">Method</th>
              <th className="p-3">Amount</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.id} className="border-b border-[var(--primary)]/10 hover:bg-[#1f1f1f]/50">
                <td className="p-3 text-white">{b.id}</td>
                <td className="p-3 text-gray-300">{b.customerName}</td>
                <td className="p-3 text-gray-300 uppercase">{b.paymentMethod}</td>
                <td className="p-3 text-[var(--primary)]">{formatCurrency(b.totalAmount)}</td>
                <td className="p-3"><span className={`badge ${b.paymentStatus === 'Paid' ? 'badge-green' : b.paymentStatus === 'Failed' ? 'badge-red' : 'badge-yellow'}`}>{b.paymentStatus}</span></td>
                <td className="p-3">
                  <select value={b.paymentStatus} onChange={(e) => updateBooking(b.id, { paymentStatus: e.target.value as Booking['paymentStatus'] })} className="bg-[#1f1f1f] text-white text-xs border border-[var(--primary)]/20 rounded px-2">
                    <option>Pending</option><option>Paid</option><option>Failed</option><option>Refunded</option>
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ReviewsTab({ reviews, approve, hide, remove }: { reviews: Review[]; approve: (id: string) => void; hide: (id: string) => void; remove: (id: string) => void }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Review Management</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reviews.map((r) => (
          <div key={r.id} className="luxury-card p-5 rounded-xl">
            <div className="flex justify-between items-start mb-2">
              <p className="text-white font-semibold">{r.userName}</p>
              <span className={`badge ${r.status === 'approved' ? 'badge-green' : r.status === 'hidden' ? 'badge-red' : 'badge-yellow'}`}>{r.status}</span>
            </div>
            <p className="text-[var(--primary)] text-sm mb-2">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</p>
            <p className="text-gray-300 text-sm mb-4">{r.comment}</p>
            <div className="flex gap-2">
              <button onClick={() => approve(r.id)} className="p-1.5 text-green-400 hover:bg-green-400/10 rounded"><CheckCircle size={16} /></button>
              <button onClick={() => hide(r.id)} className="p-1.5 text-yellow-400 hover:bg-yellow-400/10 rounded"><EyeOff size={16} /></button>
              <button onClick={() => confirm('Delete review?') && remove(r.id)} className="p-1.5 text-red-400 hover:bg-red-400/10 rounded"><Trash2 size={16} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ContactsTab({ messages, remove }: { messages: ContactMessage[]; remove: (id: string) => void }) {
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Contact Messages</h2>
      {messages.length === 0 ? <p className="text-gray-400">No messages yet.</p> : (
        <div className="space-y-3">
          {messages.map((m) => (
            <div key={m.id} className="luxury-card p-5 rounded-xl">
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-white font-semibold">{m.name}</p>
                  <p className="text-gray-400 text-xs">{m.email} • {m.mobile}</p>
                </div>
                <button onClick={() => remove(m.id)} className="text-red-400 hover:text-red-300"><Trash2 size={16} /></button>
              </div>
              <p className="text-gray-300 text-sm mt-3">{m.message}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CmsTab({ cms, updateCms }: { cms: import('../lib/types').CmsSettings; updateCms: (c: Partial<import('../lib/types').CmsSettings>) => void }) {
  const [form, setForm] = useState(cms);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">CMS Management</h2>
      <div className="luxury-card p-6 rounded-xl space-y-4">
        <input value={form.websiteName} onChange={(e) => setForm({ ...form, websiteName: e.target.value })} className="form-input" placeholder="Website Name" />
        <input value={form.heroTitle} onChange={(e) => setForm({ ...form, heroTitle: e.target.value })} className="form-input" placeholder="Hero Title" />
        <input value={form.heroSubtitle} onChange={(e) => setForm({ ...form, heroSubtitle: e.target.value })} className="form-input" placeholder="Hero Subtitle" />
        <input value={form.heroBanner} onChange={(e) => setForm({ ...form, heroBanner: e.target.value })} className="form-input" placeholder="Hero Banner URL" />
        <textarea value={form.aboutContent} onChange={(e) => setForm({ ...form, aboutContent: e.target.value })} className="form-input" rows={4} placeholder="About Us Content" />
        <textarea value={form.contactContent} onChange={(e) => setForm({ ...form, contactContent: e.target.value })} className="form-input" rows={3} placeholder="Contact Page Content" />
        <textarea value={form.footerText} onChange={(e) => setForm({ ...form, footerText: e.target.value })} className="form-input" rows={2} placeholder="Footer Text" />
        <textarea value={form.termsContent} onChange={(e) => setForm({ ...form, termsContent: e.target.value })} className="form-input" rows={4} placeholder="Terms & Conditions" />
        <textarea value={form.privacyContent} onChange={(e) => setForm({ ...form, privacyContent: e.target.value })} className="form-input" rows={4} placeholder="Privacy Policy" />
        <textarea value={form.refundContent} onChange={(e) => setForm({ ...form, refundContent: e.target.value })} className="form-input" rows={4} placeholder="Refund Policy" />
        <div className="grid grid-cols-2 gap-4">
          <input type="color" value={form.primaryColor} onChange={(e) => setForm({ ...form, primaryColor: e.target.value })} className="form-input h-12" />
          <input type="color" value={form.secondaryColor} onChange={(e) => setForm({ ...form, secondaryColor: e.target.value })} className="form-input h-12" />
        </div>
        <button onClick={() => { updateCms(form); alert('CMS saved'); }} className="btn-primary">Save CMS</button>
      </div>
    </div>
  );
}

function WebsiteTab({ website, updateWebsite }: { website: import('../lib/types').WebsiteSettings; updateWebsite: (w: Partial<import('../lib/types').WebsiteSettings>) => void }) {
  const [form, setForm] = useState(website);

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-white">Website Settings</h2>
      <div className="luxury-card p-6 rounded-xl space-y-4">
        <textarea value={form.officeAddress} onChange={(e) => setForm({ ...form, officeAddress: e.target.value })} className="form-input" rows={2} placeholder="Office Address" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input value={form.contactNumber} onChange={(e) => setForm({ ...form, contactNumber: e.target.value })} className="form-input" placeholder="Contact Number" />
          <input value={form.whatsappNumber} onChange={(e) => setForm({ ...form, whatsappNumber: e.target.value })} className="form-input" placeholder="WhatsApp Number" />
        </div>
        <input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="form-input" placeholder="Email Address" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input value={form.facebook} onChange={(e) => setForm({ ...form, facebook: e.target.value })} className="form-input" placeholder="Facebook URL" />
          <input value={form.instagram} onChange={(e) => setForm({ ...form, instagram: e.target.value })} className="form-input" placeholder="Instagram URL" />
          <input value={form.twitter} onChange={(e) => setForm({ ...form, twitter: e.target.value })} className="form-input" placeholder="Twitter URL" />
          <input value={form.youtube} onChange={(e) => setForm({ ...form, youtube: e.target.value })} className="form-input" placeholder="YouTube URL" />
        </div>
        <input value={form.googleMaps} onChange={(e) => setForm({ ...form, googleMaps: e.target.value })} className="form-input" placeholder="Google Maps Embed URL" />
        <button onClick={() => { updateWebsite(form); alert('Website settings saved'); }} className="btn-primary">Save Settings</button>
      </div>
    </div>
  );
}
