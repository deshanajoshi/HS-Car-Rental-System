import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Mail, Phone, MapPin, Lock, Save } from 'lucide-react';
import { useApp } from '../lib/context';

export default function Profile() {
  const { state, updateUser, logout } = useApp();
  const navigate = useNavigate();
  const user = state.currentUser;

  useEffect(() => {
    if (!user) navigate('/login');
  }, [user, navigate]);

  if (!user) return null;

  const [form, setForm] = useState({
    fullName: user.fullName,
    email: user.email,
    mobile: user.mobile,
    address: user.address,
    city: user.city,
    state: user.state,
    pincode: user.pincode,
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [message, setMessage] = useState('');

  const handleUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const updates: Partial<typeof user> = {
      fullName: form.fullName,
      email: form.email,
      mobile: form.mobile,
      address: form.address,
      city: form.city,
      state: form.state,
      pincode: form.pincode,
    };

    if (form.newPassword) {
      if (form.currentPassword !== user.password) {
        setMessage('Current password is incorrect');
        return;
      }
      if (form.newPassword !== form.confirmPassword) {
        setMessage('New passwords do not match');
        return;
      }
      updates.password = form.newPassword;
    }

    updateUser(updates);
    setMessage('Profile updated successfully');
    setTimeout(() => setMessage(''), 3000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-3xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-2">My <span className="gold-text">Profile</span></h1>
        <p className="text-gray-400 mb-8">Manage your account details and password</p>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="luxury-card p-8 rounded-2xl">
          {message && (
            <div className={`p-3 rounded-lg text-sm mb-4 ${message.includes('success') ? 'bg-green-500/10 text-green-400 border border-green-500/30' : 'bg-red-500/10 text-red-400 border border-red-500/30'}`}>
              {message}
            </div>
          )}

          <form onSubmit={handleUpdate} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input icon={User} label="Full Name" value={form.fullName} onChange={(v) => setForm({ ...form, fullName: v })} />
              <Input icon={Mail} label="Email" type="email" value={form.email} onChange={(v) => setForm({ ...form, email: v })} />
              <Input icon={Phone} label="Mobile" value={form.mobile} onChange={(v) => setForm({ ...form, mobile: v.replace(/\D/g, '').slice(0, 10) })} />
              <Input icon={MapPin} label="Address" value={form.address} onChange={(v) => setForm({ ...form, address: v })} />
              <Input label="City" value={form.city} onChange={(v) => setForm({ ...form, city: v })} />
              <Input label="State" value={form.state} onChange={(v) => setForm({ ...form, state: v })} />
              <Input label="Pincode" value={form.pincode} onChange={(v) => setForm({ ...form, pincode: v.replace(/\D/g, '').slice(0, 6) })} />
            </div>

            <div className="border-t border-[var(--primary)]/20 pt-6">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2"><Lock size={18} className="text-[var(--primary)]" /> Change Password</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input label="Current Password" type="password" value={form.currentPassword} onChange={(v) => setForm({ ...form, currentPassword: v })} />
                <Input label="New Password" type="password" value={form.newPassword} onChange={(v) => setForm({ ...form, newPassword: v })} />
                <Input label="Confirm New Password" type="password" value={form.confirmPassword} onChange={(v) => setForm({ ...form, confirmPassword: v })} />
              </div>
            </div>

            <div className="flex gap-4">
              <button type="submit" className="btn-primary flex items-center gap-2"><Save size={18} /> Save Changes</button>
              <button type="button" onClick={logout} className="btn-outline">Logout</button>
            </div>
          </form>
        </motion.div>
      </div>
    </div>
  );
}

function Input({ icon: Icon, label, value, onChange, type = 'text' }: { icon?: typeof User; label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <div>
      <label className="text-sm text-gray-400 block mb-1">{label}</label>
      <div className="relative">
        {Icon && <Icon size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />}
        <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className={`form-input ${Icon ? 'pl-10' : ''}`} />
      </div>
    </div>
  );
}
