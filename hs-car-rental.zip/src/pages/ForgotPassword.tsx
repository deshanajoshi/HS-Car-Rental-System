import { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, ArrowLeft, CheckCircle } from 'lucide-react';
import { useApp } from '../lib/context';
import { validateEmail } from '../lib/utils';

export default function ForgotPassword() {
  const { state } = useApp();
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateEmail(email)) {
      setError('Please enter a valid email');
      return;
    }
    const user = state.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) {
      setError('No account found with this email');
      return;
    }
    setError('');
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center py-12 px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="luxury-card p-8 rounded-2xl">
          <Link to="/login" className="text-gray-400 hover:text-[var(--primary)] flex items-center gap-1 text-sm mb-6">
            <ArrowLeft size={16} /> Back to Login
          </Link>

          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-white mb-2">Reset Password</h1>
            <p className="text-gray-400 text-sm">Enter your email and we'll send you reset instructions.</p>
          </div>

          {submitted ? (
            <div className="text-center py-6">
              <CheckCircle size={48} className="text-[var(--primary)] mx-auto mb-4" />
              <p className="text-white mb-2">Reset link sent!</p>
              <p className="text-gray-400 text-sm">Please check your email inbox for password reset instructions.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-lg text-sm">{error}</div>}
              <div>
                <label className="text-sm text-gray-400 block mb-1">Email Address</label>
                <div className="relative">
                  <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="form-input pl-10" placeholder="you@example.com" required />
                </div>
              </div>
              <button type="submit" className="w-full btn-primary">Send Reset Link</button>
            </form>
          )}
        </div>
      </motion.div>
    </div>
  );
}
