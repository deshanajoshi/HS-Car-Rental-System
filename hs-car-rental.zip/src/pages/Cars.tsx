import { useState, useMemo } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Sliders, Star, Fuel, Settings, Users } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, classNames } from '../lib/utils';

export default function Cars() {
  const { state } = useApp();
  const [searchParams] = useSearchParams();
  const brandParam = searchParams.get('brand') || '';

  const [filters, setFilters] = useState({
    brand: brandParam,
    fuel: '',
    transmission: '',
    minPrice: '',
    maxPrice: '',
    seating: '',
    search: '',
  });

  const filteredCars = useMemo(() => {
    return state.cars.filter((car) => {
      if (car.status === 'disabled') return false;
      if (filters.brand && car.brand !== filters.brand) return false;
      if (filters.fuel && car.fuelType !== filters.fuel) return false;
      if (filters.transmission && car.transmission !== filters.transmission) return false;
      if (filters.seating && car.seatingCapacity !== Number(filters.seating)) return false;
      if (filters.minPrice && car.pricePerDay < Number(filters.minPrice)) return false;
      if (filters.maxPrice && car.pricePerDay > Number(filters.maxPrice)) return false;
      if (filters.search) {
        const q = filters.search.toLowerCase();
        const match =
          car.name.toLowerCase().includes(q) ||
          car.brand.toLowerCase().includes(q) ||
          car.model.toLowerCase().includes(q) ||
          car.fuelType.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    });
  }, [state.cars, filters]);

  const brands = [...new Set(state.cars.map((c) => c.brand))];
  const fuels = [...new Set(state.cars.map((c) => c.fuelType))];
  const transmissions = [...new Set(state.cars.map((c) => c.transmission))];
  const seatings = [...new Set(state.cars.map((c) => c.seatingCapacity))].sort((a, b) => a - b);

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-10">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">Our <span className="gold-text">Fleet</span></h1>
          <p className="text-gray-400">Find the perfect car for your journey</p>
        </div>

        {/* Search bar */}
        <div className="mb-8">
          <div className="relative max-w-2xl mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search by car name, brand, model or fuel type..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className="form-input pl-12"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters */}
          <div className="lg:col-span-1">
            <div className="luxury-card p-5 rounded-xl sticky top-24">
              <div className="flex items-center gap-2 mb-5">
                <Sliders size={18} className="text-[var(--primary)]" />
                <h3 className="text-white font-semibold">Filters</h3>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm text-gray-400 block mb-1">Brand</label>
                  <select value={filters.brand} onChange={(e) => setFilters({ ...filters, brand: e.target.value })} className="form-input text-sm">
                    <option value="">All Brands</option>
                    {brands.map((b) => <option key={b} value={b}>{b}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-1">Fuel Type</label>
                  <select value={filters.fuel} onChange={(e) => setFilters({ ...filters, fuel: e.target.value })} className="form-input text-sm">
                    <option value="">All Fuels</option>
                    {fuels.map((f) => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-1">Transmission</label>
                  <select value={filters.transmission} onChange={(e) => setFilters({ ...filters, transmission: e.target.value })} className="form-input text-sm">
                    <option value="">All</option>
                    {transmissions.map((t) => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-1">Seating Capacity</label>
                  <select value={filters.seating} onChange={(e) => setFilters({ ...filters, seating: e.target.value })} className="form-input text-sm">
                    <option value="">All</option>
                    {seatings.map((s) => <option key={s} value={s}>{s} Seats</option>)}
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-400 block mb-2">Price Range (₹/day)</label>
                  <div className="grid grid-cols-2 gap-2">
                    <input type="number" placeholder="Min" value={filters.minPrice} onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })} className="form-input text-sm" />
                    <input type="number" placeholder="Max" value={filters.maxPrice} onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })} className="form-input text-sm" />
                  </div>
                </div>

                <button
                  onClick={() => setFilters({ brand: '', fuel: '', transmission: '', minPrice: '', maxPrice: '', seating: '', search: '' })}
                  className="w-full btn-outline text-sm"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          </div>

          {/* Car grid */}
          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-5">
              <p className="text-gray-400 text-sm">{filteredCars.length} cars found</p>
            </div>

            {filteredCars.length === 0 ? (
              <div className="text-center py-20 luxury-card rounded-xl">
                <p className="text-gray-400 text-lg">No cars match your filters.</p>
                <button onClick={() => setFilters({ brand: '', fuel: '', transmission: '', minPrice: '', maxPrice: '', seating: '', search: '' })} className="mt-4 btn-primary text-sm">Clear Filters</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {filteredCars.map((car) => (
                  <motion.div key={car.id} whileHover={{ y: -4 }} className="luxury-card rounded-xl overflow-hidden flex flex-col">
                    <div className="relative h-48">
                      <img src={car.images[0]} alt={car.name} className="w-full h-full object-cover" />
                      <div className="absolute top-3 left-3">
                        <span className="badge badge-gold">{car.brand}</span>
                      </div>
                      <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/60 px-2 py-1 rounded-full">
                        <Star size={12} className="text-[var(--primary)] fill-[var(--primary)]" />
                        <span className="text-xs text-white">{car.rating}</span>
                      </div>
                      <div className="absolute bottom-3 left-3 right-3 flex gap-2">
                        <span className="badge badge-green flex items-center gap-1"><Fuel size={10} /> {car.fuelType}</span>
                        <span className="badge badge-green flex items-center gap-1"><Settings size={10} /> {car.transmission}</span>
                        <span className="badge badge-green flex items-center gap-1"><Users size={10} /> {car.seatingCapacity}</span>
                      </div>
                    </div>
                    <div className="p-5 flex-grow flex flex-col">
                      <h3 className="text-lg font-bold text-white mb-1">{car.name}</h3>
                      <p className="text-gray-400 text-sm mb-3">{car.model} • {car.registrationNo}</p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        {car.features.slice(0, 3).map((f, i) => (
                          <span key={i} className="text-xs text-gray-400 bg-[#1f1f1f] px-2 py-1 rounded">{f}</span>
                        ))}
                      </div>
                      <div className="mt-auto flex items-end justify-between">
                        <div>
                          <p className="text-[var(--primary)] font-bold text-lg">{formatCurrency(car.pricePerDay)}<span className="text-xs text-gray-400 font-normal">/day</span></p>
                          <p className="text-gray-400 text-xs">{formatCurrency(car.pricePerHour)}/hr • Deposit {formatCurrency(car.securityDeposit)}</p>
                        </div>
                        <Link to={`/cars/${car.id}`} className="btn-primary text-sm">Book Now</Link>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
