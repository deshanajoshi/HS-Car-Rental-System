import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CreditCard, Upload, CheckCircle, AlertCircle, QrCode, Banknote } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency } from '../lib/utils';

export default function Payment() {
  const { bookingId } = useParams<{ bookingId: string }>();
  const { state, updateBooking, addNotification } = useApp();
  const navigate = useNavigate();
  const booking = state.bookings.find((b) => b.id === bookingId);
  const car = state.cars.find((c) => c.id === booking?.carId);
  const [method, setMethod] = useState<'upi' | 'cod'>('upi');
  const [screenshot, setScreenshot] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!booking) {
      navigate('/cars');
    }
  }, [booking, navigate]);

  if (!booking || !car) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePayment = () => {
    if (method === 'upi' && !screenshot) {
      alert('Please upload payment screenshot for UPI payment.');
      return;
    }

    const updates: Partial<typeof booking> = {
      paymentMethod: method,
      paymentStatus: method === 'upi' ? 'Paid' : 'Pending',
      bookingStatus: method === 'upi' ? 'Approved' : 'Pending',
    };
    if (screenshot) updates.paymentScreenshot = screenshot;

    updateBooking(booking.id, updates);

    addNotification({
      type: 'payment',
      title: method === 'upi' ? 'Payment Received' : 'COD Booking Pending',
      message: `Booking ${booking.id} payment via ${method.toUpperCase()} - ${formatCurrency(booking.totalAmount)}`,
      read: false,
    });

    navigate(`/confirmation/${booking.id}`);
  };

  // Generate QR data URL dynamically
  const qrDataUrl = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=${encodeURIComponent(state.website.upiId)}&pn=${encodeURIComponent('HS CAR RENTAL')}&am=${booking.totalAmount}&cu=INR&tn=${encodeURIComponent(booking.id)}`;

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl font-bold text-white mb-2">Payment</h1>
        <p className="text-gray-400 mb-8">Choose your payment method and complete the booking</p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="luxury-card p-6 rounded-xl">
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2"><CreditCard size={20} className="text-[var(--primary)]" /> Payment Method</h2>

            <div className="space-y-3 mb-6">
              <button
                onClick={() => setMethod('upi')}
                className={`w-full p-4 rounded-lg border flex items-center gap-3 transition-all ${method === 'upi' ? 'border-[var(--primary)] bg-[var(--primary)]/10' : 'border-[var(--primary)]/20 bg-[#1f1f1f]'}`}
              >
                <QrCode size={24} className="text-[var(--primary)]" />
                <div className="text-left">
                  <p className="text-white font-medium">UPI QR Payment</p>
                  <p className="text-xs text-gray-400">Scan QR code with any UPI app</p>
                </div>
              </button>

              {state.website.codEnabled && (
                <button
                  onClick={() => setMethod('cod')}
                  className={`w-full p-4 rounded-lg border flex items-center gap-3 transition-all ${method === 'cod' ? 'border-[var(--primary)] bg-[var(--primary)]/10' : 'border-[var(--primary)]/20 bg-[#1f1f1f]'}`}
                >
                  <Banknote size={24} className="text-[var(--primary)]" />
                  <div className="text-left">
                    <p className="text-white font-medium">Cash on Delivery (COD)</p>
                    <p className="text-xs text-gray-400">Pay at pickup. Booking remains pending approval.</p>
                  </div>
                </button>
              )}
            </div>

            {method === 'upi' && (
              <div className="text-center">
                <p className="text-sm text-gray-400 mb-3">Scan this QR code to pay <span className="text-[var(--primary)] font-bold">{formatCurrency(booking.totalAmount)}</span></p>
                <div className="bg-white p-3 rounded-xl inline-block mb-3">
                  <img src={qrDataUrl} alt="UPI QR Code" className="w-52 h-52" />
                </div>
                <p className="text-white font-semibold">UPI ID: {state.website.upiId}</p>
                <p className="text-xs text-gray-400 mt-1">Booking ID: {booking.id}</p>

                <div className="mt-6 text-left">
                  <label className="text-sm text-gray-400 block mb-2">Upload Payment Screenshot</label>
                  <input type="file" accept="image/*" ref={fileRef} onChange={handleFileChange} className="hidden" />
                  <button
                    type="button"
                    onClick={() => fileRef.current?.click()}
                    className="w-full p-4 border border-dashed border-[var(--primary)]/40 rounded-lg flex flex-col items-center justify-center gap-2 text-gray-300 hover:bg-[var(--primary)]/5"
                  >
                    {screenshot ? (
                      <img src={screenshot} alt="Screenshot" className="w-full h-40 object-contain rounded" />
                    ) : (
                      <>
                        <Upload size={24} className="text-[var(--primary)]" />
                        <span>Click to upload screenshot</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            {method === 'cod' && (
              <div className="bg-[var(--primary)]/10 border border-[var(--primary)]/30 p-4 rounded-lg flex items-start gap-3">
                <AlertCircle size={20} className="text-[var(--primary)] mt-0.5 shrink-0" />
                <p className="text-sm text-gray-300">You have selected Cash on Delivery. Your booking will remain Pending Approval until the admin verifies it. You can pay the total amount at the time of car pickup.</p>
              </div>
            )}
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="luxury-card p-6 rounded-xl h-fit">
            <h2 className="text-xl font-semibold text-white mb-4">Booking Summary</h2>
            <div className="flex gap-4 mb-4">
              <img src={car.images[0]} alt={car.name} className="w-24 h-16 object-cover rounded-lg" />
              <div>
                <p className="text-white font-semibold">{car.name}</p>
                <p className="text-gray-400 text-xs">{car.brand} {car.model}</p>
              </div>
            </div>
            <div className="space-y-2 text-sm text-gray-300 mb-4">
              <p><span className="text-gray-500">Booking ID:</span> {booking.id}</p>
              <p><span className="text-gray-500">Customer:</span> {booking.customerName}</p>
              <p><span className="text-gray-500">Pickup:</span> {booking.pickupDate} {booking.pickupTime}</p>
              <p><span className="text-gray-500">Return:</span> {booking.returnDate} {booking.returnTime}</p>
              <p><span className="text-gray-500">Duration:</span> {booking.days} days ({booking.hours} hours)</p>
            </div>
            <div className="border-t border-[var(--primary)]/10 pt-4 space-y-2">
              <div className="flex justify-between text-gray-300 text-sm">
                <span>Rental Amount</span>
                <span>{formatCurrency(booking.totalAmount - booking.securityDeposit)}</span>
              </div>
              <div className="flex justify-between text-gray-300 text-sm">
                <span>Security Deposit</span>
                <span>{formatCurrency(booking.securityDeposit)}</span>
              </div>
              <div className="flex justify-between text-[var(--primary)] font-bold text-lg border-t border-[var(--primary)]/20 pt-2">
                <span>Total Payable</span>
                <span>{formatCurrency(booking.totalAmount)}</span>
              </div>
            </div>
            <button onClick={handlePayment} className="w-full btn-primary mt-6 flex items-center justify-center gap-2">
              <CheckCircle size={18} /> {method === 'upi' ? 'I Have Paid' : 'Request COD Booking'}
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
