import { useApp } from '../lib/context';

export default function Refund() {
  const { state } = useApp();
  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center">Refund <span className="gold-text">Policy</span></h1>
        <div className="luxury-card p-8 rounded-2xl">
          <div className="text-gray-300 leading-relaxed whitespace-pre-line">{state.cms.refundContent}</div>
          <div className="mt-8 space-y-4 text-gray-300 text-sm">
            <h3 className="text-white font-semibold text-lg">Cancellation & Refund Rules</h3>
            <ul className="list-disc list-inside space-y-2">
              <li>Cancellation 24+ hours before pickup: 100% refund minus processing fee.</li>
              <li>Cancellation 6-24 hours before pickup: 50% refund.</li>
              <li>Cancellation less than 6 hours before pickup: no refund.</li>
              <li>Security deposit is refunded within 5-7 working days after car return.</li>
              <li>Refunds are processed to the original payment method.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
