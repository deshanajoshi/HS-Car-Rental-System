import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Mail, Lock } from 'lucide-react';
import { useApp } from '../lib/context';

export default function Login() {
  const { login } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as { from?: { pathname?: string } })?.from?.pathname || '/';
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const user = login(form.email, form.password);
    if (user) {
      navigate(user.role === 'admin' ? '/admin' : from);
    } else {
      setError('Invalid email or password');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center py-12 px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-md">
        <div className="luxury-card p-8 rounded-2xl">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-white mb-2">Welcome Back</h1>
            <p className="text-gray-400 text-sm">Login to your HS CAR RENTAL account</p>
          </div>

          {error && <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-lg text-sm mb-4">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 block mb-1">Email Address</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="form-input pl-10" placeholder="you@example.com" required />
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-1">Password</label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input type={showPassword ? 'text' : 'password'} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} className="form-input pl-10 pr-10" placeholder="••••••" required />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[var(--primary)]">
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>
            <div className="flex justify-between items-center text-sm">
              <label className="flex items-center gap-2 text-gray-400">
                <input type="checkbox" className="accent-[var(--primary)]" /> Remember me
              </label>
              <Link to="/forgot-password" className="text-[var(--primary)] hover:underline">Forgot password?</Link>
            </div>
            <button type="submit" className="w-full btn-primary">Login</button>
          </form>

          <p className="text-center text-sm text-gray-400 mt-6">
            Don't have an account? <Link to="/register" className="text-[var(--primary)] hover:underline">Register</Link>
          </p>

          <div className="mt-6 p-3 bg-[var(--primary)]/10 rounded-lg text-xs text-gray-400 text-center">
            <p className="font-semibold text-[var(--primary)]">Demo Credentials</p>
            <p>Admin: admin@hscarrental.com / admin123</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
