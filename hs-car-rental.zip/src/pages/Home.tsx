import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Star, Shield, Clock, Headphones, Car, Calendar, CheckCircle, ChevronDown, MapPin, Phone, Mail } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, classNames } from '../lib/utils';

const faqs = [
  { q: 'What documents are required to rent a car?', a: 'You need a valid driving license, Aadhaar card and a passport size photograph. Two persons KYC details are mandatory for every booking.' },
  { q: 'Is there a security deposit?', a: 'Yes, a refundable security deposit is collected at the time of pickup. The amount varies by car model and is shown on the car details page.' },
  { q: 'Can I pay via UPI or COD?', a: 'Absolutely. We support secure UPI QR payments and Cash on Delivery (COD). COD bookings require admin approval before confirmation.' },
  { q: 'What is the cancellation policy?', a: 'Cancellations made 24 hours before pickup are eligible for full refund. Late cancellations may attract charges as per our refund policy.' },
  { q: 'Do you offer doorstep delivery?', a: 'Yes, doorstep delivery and pickup is available in selected cities. Charges may apply based on distance.' },
];

const whyChoose = [
  { icon: Shield, title: 'Verified Cars', desc: 'Every car is inspected and sanitized before every trip.' },
  { icon: Clock, title: '24/7 Support', desc: 'Round the clock roadside assistance and customer support.' },
  { icon: Car, title: 'Wide Fleet', desc: 'Luxury, SUV, sedan, hatchback and electric cars available.' },
  { icon: Calendar, title: 'Flexible Rental', desc: 'Rent by the hour or by the day as per your need.' },
];

export default function Home() {
  const { state, addContactMessage, addNotification } = useApp();
  const navigate = useNavigate();
  const [searchBrand, setSearchBrand] = useState('');
  const [searchLocation, setSearchLocation] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [contactForm, setContactForm] = useState({ name: '', email: '', mobile: '', message: '' });
  const [toast, setToast] = useState('');

  useEffect(() => {
    if (toast) {
      const t = setTimeout(() => setToast(''), 3000);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const featuredCars = state.cars.filter((c) => c.featured && c.status !== 'disabled').slice(0, 3);
  const popularCars = state.cars.filter((c) => c.popular && c.status !== 'disabled').slice(0, 4);
  const latestCars = state.cars.filter((c) => c.latest && c.status !== 'disabled').slice(0, 4);
  const approvedReviews = state.reviews.filter((r) => r.status === 'approved').slice(0, 6);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchBrand) params.set('brand', searchBrand);
    if (searchLocation) params.set('location', searchLocation);
    navigate(`/cars?${params.toString()}`);
  };

  const handleContact = (e: React.FormEvent) => {
    e.preventDefault();
    addContactMessage(contactForm);
    addNotification({
      type: 'contact',
      title: 'New Contact Message',
      message: `${contactForm.name} sent a message`,
      read: false,
    });
    setContactForm({ name: '', email: '', mobile: '', message: '' });
    setToast('Message sent successfully! We will contact you soon.');
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative min-h-[90vh] flex items-center">
        <div className="absolute inset-0">
          <img src={state.cms.heroBanner} alt="Luxury Car" className="w-full h-full object-cover" />
          <div className="hero-overlay absolute inset-0" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 w-full py-20">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="max-w-2xl">
            <p className="text-[var(--primary)] font-semibold tracking-widest mb-4">PREMIUM CAR RENTAL INDIA</p>
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">{state.cms.heroTitle}</h1>
            <p className="text-lg text-gray-300 mb-8">{state.cms.heroSubtitle}</p>
            <div className="flex flex-wrap gap-4">
              <Link to="/cars" className="btn-primary">Browse Cars</Link>
              <a href="#contact" className="btn-outline">Contact Us</a>
            </div>
          </motion.div>

          {/* Search box */}
          <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="mt-12 bg-[#121212]/90 backdrop-blur-md border border-[var(--primary)]/30 p-6 rounded-xl max-w-4xl">
            <h3 className="text-white font-semibold mb-4 flex items-center gap-2"><Search size={18} className="text-[var(--primary)]" /> Search Your Car</h3>
            <form onSubmit={handleSearch} className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <select value={searchBrand} onChange={(e) => setSearchBrand(e.target.value)} className="form-input">
                <option value="">All Brands</option>
                {[...new Set(state.cars.map((c) => c.brand))].map((b) => <option key={b} value={b}>{b}</option>)}
              </select>
              <input type="text" placeholder="Pickup Location" value={searchLocation} onChange={(e) => setSearchLocation(e.target.value)} className="form-input" />
              <button type="submit" className="btn-primary flex items-center justify-center gap-2"><Search size={18} /> Search Cars</button>
            </form>
          </motion.div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="section-title">Why Choose <span className="gold-text">HS CAR RENTAL</span></h2>
          <p className="section-subtitle">Premium service, transparent pricing and unmatched convenience</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {whyChoose.map((item, idx) => (
              <motion.div key={idx} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.1 }} className="luxury-card p-6 rounded-xl text-center">
                <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-[var(--primary)]/10 flex items-center justify-center">
                  <item.icon size={28} className="text-[var(--primary)]" />
                </div>
                <h3 className="text-white font-semibold mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Cars */}
      <section className="py-20 bg-[#121212]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="section-title">Featured <span className="gold-text">Cars</span></h2>
          <p className="section-subtitle">Handpicked premium vehicles for a luxurious drive</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCars.map((car) => (
              <CarCard key={car.id} car={car} />
            ))}
          </div>
          <div className="text-center mt-10">
            <Link to="/cars" className="btn-outline">View All Cars</Link>
          </div>
        </div>
      </section>

      {/* Popular Cars */}
      <section className="py-20 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="section-title">Popular <span className="gold-text">Cars</span></h2>
          <p className="section-subtitle">Most rented cars by our customers</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularCars.map((car) => (
              <CarCard key={car.id} car={car} compact />
            ))}
          </div>
        </div>
      </section>

      {/* Latest Cars */}
      <section className="py-20 bg-[#121212]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="section-title">Latest <span className="gold-text">Additions</span></h2>
          <p className="section-subtitle">Newly added cars to our premium fleet</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {latestCars.map((car) => (
              <CarCard key={car.id} car={car} compact />
            ))}
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-20 bg-[#0a0a0a]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="section-title">Customer <span className="gold-text">Reviews</span></h2>
          <p className="section-subtitle">What our customers say about us</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {approvedReviews.map((review) => (
              <div key={review.id} className="luxury-card p-6 rounded-xl">
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} size={16} className={i < review.rating ? 'text-[var(--primary)] fill-[var(--primary)]' : 'text-gray-600'} />
                  ))}
                </div>
                <p className="text-gray-300 mb-4 italic">"{review.comment}"</p>
                <p className="text-[var(--primary)] font-semibold text-sm">- {review.userName}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About preview */}
      <section id="about" className="py-20 bg-[#121212]">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img src="https://images.unsplash.com/photo-1485291571150-772bcfc10da5?auto=format&fit=crop&w=800&q=80" alt="About HS CAR RENTAL" className="rounded-xl shadow-2xl border border-[var(--primary)]/20" />
            </div>
            <div>
              <p className="text-[var(--primary)] font-semibold tracking-widest mb-2">ABOUT US</p>
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">India's Trusted Premium Car Rental</h2>
              <div className="text-gray-300 leading-relaxed whitespace-pre-line mb-6">{state.cms.aboutContent}</div>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-[#1f1f1f] p-4 rounded-lg border border-[var(--primary)]/10">
                  <p className="text-2xl font-bold text-[var(--primary)]">{state.cars.length}+</p>
                  <p className="text-sm text-gray-400">Premium Cars</p>
                </div>
                <div className="bg-[#1f1f1f] p-4 rounded-lg border border-[var(--primary)]/10">
                  <p className="text-2xl font-bold text-[var(--primary)]">{state.bookings.length}+</p>
                  <p className="text-sm text-gray-400">Happy Rentals</p>
                </div>
              </div>
              <Link to="/about" className="btn-primary">Read More</Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 bg-[#0a0a0a]">
        <div className="max-w-3xl mx-auto px-4">
          <h2 className="section-title">Frequently Asked <span className="gold-text">Questions</span></h2>
          <p className="section-subtitle">Find answers to common queries</p>
          <div className="space-y-3">
            {faqs.map((faq, idx) => (
              <div key={idx} className="luxury-card rounded-lg overflow-hidden">
                <button onClick={() => setOpenFaq(openFaq === idx ? null : idx)} className="w-full flex justify-between items-center p-4 text-left">
                  <span className="font-medium text-white">{faq.q}</span>
                  <ChevronDown size={18} className={classNames('text-[var(--primary)] transition-transform', openFaq === idx && 'rotate-180')} />
                </button>
                {openFaq === idx && (
                  <div className="px-4 pb-4 text-gray-400 text-sm">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-20 bg-[#121212]">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="section-title">Contact <span className="gold-text">Us</span></h2>
          <p className="section-subtitle">Get in touch with our team</p>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <div className="space-y-6">
              <p className="text-gray-300">{state.cms.contactContent}</p>
              <div className="flex items-center gap-4 p-4 bg-[#1f1f1f] rounded-lg border border-[var(--primary)]/10">
                <Phone className="text-[var(--primary)]" />
                <div>
                  <p className="text-sm text-gray-400">Phone / WhatsApp</p>
                  <p className="text-white font-medium">{state.website.contactNumber}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-[#1f1f1f] rounded-lg border border-[var(--primary)]/10">
                <Mail className="text-[var(--primary)]" />
                <div>
                  <p className="text-sm text-gray-400">Email</p>
                  <p className="text-white font-medium">{state.website.email}</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-[#1f1f1f] rounded-lg border border-[var(--primary)]/10">
                <MapPin className="text-[var(--primary)]" />
                <div>
                  <p className="text-sm text-gray-400">Office</p>
                  <p className="text-white font-medium">{state.website.officeAddress}</p>
                </div>
              </div>
            </div>
            <form onSubmit={handleContact} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input type="text" placeholder="Full Name" value={contactForm.name} onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })} className="form-input" required />
                <input type="email" placeholder="Email" value={contactForm.email} onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })} className="form-input" required />
              </div>
              <input type="tel" placeholder="Mobile Number" value={contactForm.mobile} onChange={(e) => setContactForm({ ...contactForm, mobile: e.target.value })} className="form-input" required />
              <textarea rows={5} placeholder="Your Message" value={contactForm.message} onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })} className="form-input" required />
              <button type="submit" className="btn-primary w-full">Send Message</button>
            </form>
          </div>
        </div>
      </section>

      {toast && (
        <div className="toast flex items-center gap-2">
          <CheckCircle size={18} className="text-[var(--primary)]" />
          {toast}
        </div>
      )}
    </div>
  );
}

function CarCard({ car, compact = false }: { car: import('../lib/types').Car; compact?: boolean }) {
  return (
    <motion.div whileHover={{ y: -4 }} className="luxury-card rounded-xl overflow-hidden flex flex-col">
      <div className="relative h-48">
        <img src={car.images[0]} alt={car.name} className="w-full h-full object-cover" />
        <div className="absolute top-3 left-3">
          <span className="badge badge-gold">{car.brand}</span>
        </div>
        <div className="absolute top-3 right-3 flex items-center gap-1 bg-black/60 px-2 py-1 rounded-full">
          <Star size={12} className="text-[var(--primary)] fill-[var(--primary)]" />
          <span className="text-xs text-white">{car.rating}</span>
        </div>
      </div>
      <div className="p-5 flex-grow flex flex-col">
        <h3 className="text-lg font-bold text-white mb-1">{car.name}</h3>
        <p className="text-gray-400 text-sm mb-3">{car.transmission} • {car.fuelType} • {car.seatingCapacity} Seats</p>
        <div className="mt-auto flex items-end justify-between">
          <div>
            <p className="text-[var(--primary)] font-bold text-lg">{formatCurrency(car.pricePerDay)}<span className="text-xs text-gray-400 font-normal">/day</span></p>
            <p className="text-gray-400 text-xs">{formatCurrency(car.pricePerHour)}/hr</p>
          </div>
          <Link to={`/cars/${car.id}`} className="btn-primary text-sm">View Details</Link>
        </div>
      </div>
    </motion.div>
  );
}
