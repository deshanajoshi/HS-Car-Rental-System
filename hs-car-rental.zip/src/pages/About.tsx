import { motion } from 'framer-motion';
import { Shield, Clock, Car, Award, Users, Globe } from 'lucide-react';
import { useApp } from '../lib/context';

const features = [
  { icon: Shield, title: 'Safety First', desc: 'All cars undergo regular maintenance and safety checks.' },
  { icon: Clock, title: 'Punctual Service', desc: 'On-time pickup and drop-off across serviceable cities.' },
  { icon: Award, title: 'Premium Quality', desc: 'Curated fleet of luxury and well-maintained vehicles.' },
  { icon: Users, title: 'Customer Focus', desc: 'Dedicated support team to assist you at every step.' },
  { icon: Globe, title: 'Wide Coverage', desc: 'Serving major cities and airports across India.' },
  { icon: Car, title: 'Variety', desc: 'Sedans, SUVs, hatchbacks, luxury cars and EVs.' },
];

export default function About() {
  const { state } = useApp();

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">About <span className="gold-text">HS CAR RENTAL</span></h1>
          <p className="text-gray-400">Your trusted partner for premium car rentals in India</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
            <img src="https://images.unsplash.com/photo-1485291571150-772bcfc10da5?auto=format&fit=crop&w=800&q=80" alt="About" className="rounded-2xl border border-[var(--primary)]/20 shadow-2xl" />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <p className="text-[var(--primary)] font-semibold tracking-widest mb-2">WHO WE ARE</p>
            <div className="text-gray-300 leading-relaxed whitespace-pre-line text-lg">{state.cms.aboutContent}</div>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {features.map((f, idx) => (
            <motion.div key={idx} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.1 }} className="luxury-card p-6 rounded-xl text-center">
              <div className="w-14 h-14 mx-auto mb-4 rounded-full bg-[var(--primary)]/10 flex items-center justify-center">
                <f.icon size={28} className="text-[var(--primary)]" />
              </div>
              <h3 className="text-white font-semibold mb-2">{f.title}</h3>
              <p className="text-gray-400 text-sm">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
