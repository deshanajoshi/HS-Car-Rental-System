import { useApp } from '../lib/context';

export default function Privacy() {
  const { state } = useApp();
  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-white mb-6 text-center">Privacy <span className="gold-text">Policy</span></h1>
        <div className="luxury-card p-8 rounded-2xl">
          <div className="text-gray-300 leading-relaxed whitespace-pre-line">{state.cms.privacyContent}</div>
          <div className="mt-8 space-y-4 text-gray-300 text-sm">
            <h3 className="text-white font-semibold text-lg">Data Protection</h3>
            <ul className="list-disc list-inside space-y-2">
              <li>We collect only necessary personal information for booking and KYC verification.</li>
              <li>Your Aadhaar and mobile details are stored securely and never shared with third parties.</li>
              <li>We use industry-standard encryption and security practices.</li>
              <li>You can request deletion of your account data by contacting support.</li>
              <li>Payment screenshots are used only for verification purposes.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
