import { useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, Download, Printer, Mail, Home, FileText } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency, formatDateTime } from '../lib/utils';

export default function Confirmation() {
  const { bookingId } = useParams<{ bookingId: string }>();
  const { state } = useApp();
  const navigate = useNavigate();
  const receiptRef = useRef<HTMLDivElement>(null);
  const booking = state.bookings.find((b) => b.id === bookingId);
  const car = state.cars.find((c) => c.id === booking?.carId);

  if (!booking || !car) {
    return (
      <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-white mb-4">Booking Not Found</h2>
          <Link to="/cars" className="btn-primary">Browse Cars</Link>
        </div>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    const receiptContent = `
HS CAR RENTAL - BOOKING RECEIPT
================================
Booking ID: ${booking.id}
Status: ${booking.bookingStatus}
Payment Status: ${booking.paymentStatus}
Payment Method: ${booking.paymentMethod.toUpperCase()}

Customer Details:
Name: ${booking.customerName}
Email: ${booking.email}
Mobile: ${booking.mobile}
Address: ${booking.address}, ${booking.city}, ${booking.state} - ${booking.pincode}

Car Details:
Name: ${car.name}
Brand/Model: ${car.brand} ${car.model}
Registration: ${car.registrationNo}
Fuel: ${car.fuelType} | Transmission: ${car.transmission} | Seats: ${car.seatingCapacity}

Rental Period:
Pickup: ${formatDateTime(booking.pickupDate, booking.pickupTime)}
Return: ${formatDateTime(booking.returnDate, booking.returnTime)}
Duration: ${booking.days} days (${booking.hours} hours)

Charges:
Rental Amount: ${formatCurrency(booking.totalAmount - booking.securityDeposit)}
Security Deposit: ${formatCurrency(booking.securityDeposit)}
Total Amount: ${formatCurrency(booking.totalAmount)}

Thank you for choosing HS CAR RENTAL.
    `.trim();

    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `HS-Receipt-${booking.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-3xl mx-auto px-4">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center mb-8">
          <div className="w-20 h-20 bg-[var(--primary)]/10 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={40} className="text-[var(--primary)]" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Booking Confirmed!</h1>
          <p className="text-gray-400">Your booking has been received. A confirmation email has been sent to {booking.email}.</p>
        </motion.div>

        <div ref={receiptRef} className="luxury-card p-8 rounded-xl mb-6 print:bg-white print:text-black">
          <div className="flex justify-between items-start mb-6 border-b border-[var(--primary)]/20 pb-4">
            <div>
              <img src={state.cms.logo} alt="HS CAR RENTAL" className="h-12 w-12 mb-2" />
              <h2 className="text-xl font-bold text-white print:text-black">HS CAR RENTAL</h2>
              <p className="text-xs text-gray-400 print:text-gray-600">{state.website.officeAddress}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-400 print:text-gray-600">Booking ID</p>
              <p className="text-2xl font-bold text-[var(--primary)] print:text-black">{booking.id}</p>
              <p className="text-sm text-gray-400 print:text-gray-600 mt-1">{new Date(booking.createdAt).toLocaleDateString('en-IN')}</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <p className="text-xs text-gray-500 uppercase">Booking Status</p>
              <p className={`font-semibold ${booking.bookingStatus === 'Approved' || booking.bookingStatus === 'Active' ? 'text-green-400' : 'text-yellow-400'}`}>{booking.bookingStatus}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 uppercase">Payment Status</p>
              <p className="font-semibold text-white print:text-black">{booking.paymentStatus} ({booking.paymentMethod.toUpperCase()})</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-6">
            <div>
              <h3 className="text-[var(--primary)] font-semibold mb-2">Customer Details</h3>
              <p className="text-gray-300 print:text-black text-sm">{booking.customerName}</p>
              <p className="text-gray-300 print:text-black text-sm">{booking.email}</p>
              <p className="text-gray-300 print:text-black text-sm">{booking.mobile}</p>
              <p className="text-gray-300 print:text-black text-sm">{booking.address}</p>
              <p className="text-gray-300 print:text-black text-sm">{booking.city}, {booking.state} - {booking.pincode}</p>
            </div>
            <div>
              <h3 className="text-[var(--primary)] font-semibold mb-2">Car Details</h3>
              <p className="text-gray-300 print:text-black text-sm">{car.name}</p>
              <p className="text-gray-300 print:text-black text-sm">{car.brand} {car.model}</p>
              <p className="text-gray-300 print:text-black text-sm">Reg: {car.registrationNo}</p>
              <p className="text-gray-300 print:text-black text-sm">{car.fuelType} • {car.transmission} • {car.seatingCapacity} Seats</p>
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-[var(--primary)] font-semibold mb-2">Rental Period</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="bg-[#1f1f1f] print:bg-gray-100 p-3 rounded-lg">
                <p className="text-gray-500">Pickup</p>
                <p className="text-white print:text-black">{formatDateTime(booking.pickupDate, booking.pickupTime)}</p>
              </div>
              <div className="bg-[#1f1f1f] print:bg-gray-100 p-3 rounded-lg">
                <p className="text-gray-500">Return</p>
                <p className="text-white print:text-black">{formatDateTime(booking.returnDate, booking.returnTime)}</p>
              </div>
            </div>
            <p className="text-gray-300 print:text-black text-sm mt-2">Duration: {booking.days} days ({booking.hours} hours)</p>
          </div>

          <div className="border-t border-[var(--primary)]/20 pt-4">
            <h3 className="text-[var(--primary)] font-semibold mb-2">Charges</h3>
            <div className="space-y-1 text-sm">
              <div className="flex justify-between text-gray-300 print:text-black">
                <span>Rental Amount</span>
                <span>{formatCurrency(booking.totalAmount - booking.securityDeposit)}</span>
              </div>
              <div className="flex justify-between text-gray-300 print:text-black">
                <span>Security Deposit</span>
                <span>{formatCurrency(booking.securityDeposit)}</span>
              </div>
              <div className="flex justify-between text-[var(--primary)] font-bold text-lg pt-2">
                <span>Total Amount</span>
                <span>{formatCurrency(booking.totalAmount)}</span>
              </div>
            </div>
          </div>

          <div className="mt-6 text-center text-xs text-gray-500 print:text-gray-600">
            <p>Thank you for choosing HS CAR RENTAL.</p>
            <p>For support, contact {state.website.contactNumber} or {state.website.email}</p>
          </div>
        </div>

        <div className="flex flex-wrap justify-center gap-4 no-print">
          <button onClick={handleDownload} className="btn-primary flex items-center gap-2"><Download size={18} /> Download Receipt</button>
          <button onClick={handlePrint} className="btn-outline flex items-center gap-2"><Printer size={18} /> Print Receipt</button>
          <Link to="/" className="btn-outline flex items-center gap-2"><Home size={18} /> Home</Link>
          {state.currentUser && <Link to="/dashboard" className="btn-outline flex items-center gap-2"><FileText size={18} /> Dashboard</Link>}
        </div>
      </div>
    </div>
  );
}
