import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle } from 'lucide-react';
import { useApp } from '../lib/context';

export default function Contact() {
  const { state, addContactMessage, addNotification } = useApp();
  const [form, setForm] = useState({ name: '', email: '', mobile: '', message: '' });
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addContactMessage(form);
    addNotification({
      type: 'contact',
      title: 'New Contact Message',
      message: `${form.name} sent a message`,
      read: false,
    });
    setForm({ name: '', email: '', mobile: '', message: '' });
    setSent(true);
    setTimeout(() => setSent(false), 5000);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">Contact <span className="gold-text">Us</span></h1>
          <p className="text-gray-400 max-w-2xl mx-auto">{state.cms.contactContent}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-1 space-y-4">
            <ContactCard icon={Phone} title="Phone / WhatsApp" value={state.website.contactNumber} />
            <ContactCard icon={Mail} title="Email" value={state.website.email} />
            <ContactCard icon={MapPin} title="Office Address" value={state.website.officeAddress} />
            <ContactCard icon={Clock} title="Working Hours" value="24/7 Customer Support" />
          </motion.div>

          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="lg:col-span-2">
            <div className="luxury-card p-8 rounded-2xl">
              <h2 className="text-xl font-semibold text-white mb-6 flex items-center gap-2"><Send size={20} className="text-[var(--primary)]" /> Send Message</h2>
              {sent && (
                <div className="bg-green-500/10 border border-green-500/30 text-green-400 p-3 rounded-lg text-sm mb-4 flex items-center gap-2">
                  <CheckCircle size={16} /> Message sent successfully!
                </div>
              )}
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <input type="text" placeholder="Full Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="form-input" required />
                  <input type="email" placeholder="Email Address" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className="form-input" required />
                </div>
                <input type="tel" placeholder="Mobile Number" value={form.mobile} onChange={(e) => setForm({ ...form, mobile: e.target.value.replace(/\D/g, '').slice(0, 10) })} className="form-input" required />
                <textarea rows={5} placeholder="Your Message" value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} className="form-input" required />
                <button type="submit" className="btn-primary w-full">Send Message</button>
              </form>
            </div>
          </motion.div>
        </div>

        {state.website.googleMaps && (
          <div className="mt-12 rounded-xl overflow-hidden border border-[var(--primary)]/20 h-80">
            <iframe src={state.website.googleMaps} width="100%" height="100%" style={{ border: 0 }} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" title="Office Location"></iframe>
          </div>
        )}
      </div>
    </div>
  );
}

function ContactCard({ icon: Icon, title, value }: { icon: typeof Phone; title: string; value: string }) {
  return (
    <div className="luxury-card p-5 rounded-xl flex items-start gap-4">
      <div className="w-12 h-12 rounded-full bg-[var(--primary)]/10 flex items-center justify-center shrink-0">
        <Icon size={22} className="text-[var(--primary)]" />
      </div>
      <div>
        <h3 className="text-white font-semibold mb-1">{title}</h3>
        <p className="text-gray-400 text-sm">{value}</p>
      </div>
    </div>
  );
}
