import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, User, Mail, Lock, Phone, MapPin } from 'lucide-react';
import { useApp } from '../lib/context';
import { validateEmail, validateMobile } from '../lib/utils';

export default function Register() {
  const { register } = useApp();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    fullName: '',
    email: '',
    mobile: '',
    password: '',
    confirmPassword: '',
    address: '',
    city: '',
    state: '',
    pincode: '',
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!form.fullName.trim()) return setError('Full name is required');
    if (!validateEmail(form.email)) return setError('Valid email is required');
    if (!validateMobile(form.mobile)) return setError('Valid 10-digit mobile is required');
    if (form.password.length < 6) return setError('Password must be at least 6 characters');
    if (form.password !== form.confirmPassword) return setError('Passwords do not match');
    if (!form.address.trim() || !form.city.trim() || !form.state.trim() || !form.pincode.trim()) {
      return setError('All address fields are required');
    }

    const success = register({
      fullName: form.fullName,
      email: form.email,
      mobile: form.mobile,
      password: form.password,
      address: form.address,
      city: form.city,
      state: form.state,
      pincode: form.pincode,
    });

    if (success) {
      navigate('/');
    } else {
      setError('Email already registered');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center py-12 px-4">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="w-full max-w-xl">
        <div className="luxury-card p-8 rounded-2xl">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-white mb-2">Create Account</h1>
            <p className="text-gray-400 text-sm">Join HS CAR RENTAL for premium mobility</p>
          </div>

          {error && <div className="bg-red-500/10 border border-red-500/30 text-red-400 p-3 rounded-lg text-sm mb-4">{error}</div>}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-400 block mb-1">Full Name</label>
                <div className="relative">
                  <User size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input type="text" value={form.fullName} onChange={(e) => handleChange('fullName', e.target.value)} className="form-input pl-10" required />
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400 block mb-1">Mobile</label>
                <div className="relative">
                  <Phone size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input type="tel" value={form.mobile} onChange={(e) => handleChange('mobile', e.target.value.replace(/\D/g, '').slice(0, 10))} className="form-input pl-10" required />
                </div>
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-1">Email</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input type="email" value={form.email} onChange={(e) => handleChange('email', e.target.value)} className="form-input pl-10" required />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-gray-400 block mb-1">Password</label>
                <div className="relative">
                  <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                  <input type={showPassword ? 'text' : 'password'} value={form.password} onChange={(e) => handleChange('password', e.target.value)} className="form-input pl-10 pr-10" required />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-[var(--primary)]">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400 block mb-1">Confirm Password</label>
                <input type={showPassword ? 'text' : 'password'} value={form.confirmPassword} onChange={(e) => handleChange('confirmPassword', e.target.value)} className="form-input" required />
              </div>
            </div>
            <div>
              <label className="text-sm text-gray-400 block mb-1">Address</label>
              <div className="relative">
                <MapPin size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" />
                <input type="text" value={form.address} onChange={(e) => handleChange('address', e.target.value)} className="form-input pl-10" required />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <input type="text" placeholder="City" value={form.city} onChange={(e) => handleChange('city', e.target.value)} className="form-input" required />
              <input type="text" placeholder="State" value={form.state} onChange={(e) => handleChange('state', e.target.value)} className="form-input" required />
              <input type="text" placeholder="Pincode" value={form.pincode} onChange={(e) => handleChange('pincode', e.target.value.replace(/\D/g, '').slice(0, 6))} className="form-input" required />
            </div>
            <button type="submit" className="w-full btn-primary">Register</button>
          </form>

          <p className="text-center text-sm text-gray-400 mt-6">
            Already have an account? <Link to="/login" className="text-[var(--primary)] hover:underline">Login</Link>
          </p>
        </div>
      </motion.div>
    </div>
  );
}
