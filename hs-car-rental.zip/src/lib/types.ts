export interface Car {
  id: string;
  name: string;
  brand: string;
  model: string;
  registrationNo: string;
  fuelType: 'Petrol' | 'Diesel' | 'Electric' | 'Hybrid' | 'CNG';
  transmission: 'Manual' | 'Automatic';
  seatingCapacity: number;
  pricePerHour: number;
  pricePerDay: number;
  securityDeposit: number;
  description: string;
  features: string[];
  images: string[];
  status: 'available' | 'rented' | 'maintenance' | 'disabled';
  rating: number;
  reviewCount: number;
  featured: boolean;
  popular: boolean;
  latest: boolean;
}

export interface KycPerson {
  name: string;
  aadhaar: string;
  mobile: string;
}

export interface Booking {
  id: string;
  carId: string;
  userId: string | null;
  customerName: string;
  email: string;
  mobile: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  pickupDate: string;
  pickupTime: string;
  returnDate: string;
  returnTime: string;
  hours: number;
  days: number;
  totalAmount: number;
  securityDeposit: number;
  paymentMethod: 'upi' | 'cod';
  paymentStatus: 'Pending' | 'Paid' | 'Failed' | 'Refunded';
  bookingStatus: 'Pending' | 'Approved' | 'Rejected' | 'Active' | 'Completed' | 'Cancelled';
  kycPersons: KycPerson[];
  paymentScreenshot?: string;
  createdAt: string;
}

export interface User {
  id: string;
  fullName: string;
  email: string;
  mobile: string;
  password: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface Review {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  status: 'pending' | 'approved' | 'hidden';
  createdAt: string;
}

export interface ContactMessage {
  id: string;
  name: string;
  email: string;
  mobile: string;
  message: string;
  createdAt: string;
}

export interface CmsSettings {
  websiteName: string;
  logo: string;
  favicon: string;
  heroTitle: string;
  heroSubtitle: string;
  heroBanner: string;
  aboutContent: string;
  contactContent: string;
  footerText: string;
  termsContent: string;
  privacyContent: string;
  refundContent: string;
  primaryColor: string;
  secondaryColor: string;
}

export interface WebsiteSettings {
  officeAddress: string;
  contactNumber: string;
  whatsappNumber: string;
  email: string;
  facebook: string;
  instagram: string;
  twitter: string;
  youtube: string;
  googleMaps: string;
  upiId: string;
  qrCode: string;
  codEnabled: boolean;
}

export interface Notification {
  id: string;
  type: 'booking' | 'payment' | 'contact' | 'review';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface AppState {
  cars: Car[];
  users: User[];
  bookings: Booking[];
  reviews: Review[];
  contactMessages: ContactMessage[];
  notifications: Notification[];
  cms: CmsSettings;
  website: WebsiteSettings;
  currentUser: User | null;
}
