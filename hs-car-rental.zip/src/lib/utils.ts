export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(dateStr: string): string {
  if (!dateStr) return '';
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    return date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  } catch {
    return dateStr;
  }
}

export function formatDateTime(dateStr: string, timeStr: string): string {
  if (!dateStr) return '';
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    const [h, min] = (timeStr || '00:00').split(':').map(Number);
    const date = new Date(y, m - 1, d, h, min);
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return `${dateStr} ${timeStr}`;
  }
}

export function calculateRental(
  pickupDate: string,
  pickupTime: string,
  returnDate: string,
  returnTime: string,
  pricePerHour: number,
  pricePerDay: number
): { hours: number; days: number; total: number } {
  const start = new Date(`${pickupDate}T${pickupTime || '00:00'}`);
  const end = new Date(`${returnDate}T${returnTime || '00:00'}`);
  if (isNaN(start.getTime()) || isNaN(end.getTime()) || end <= start) {
    return { hours: 0, days: 0, total: 0 };
  }
  const diffMs = end.getTime() - start.getTime();
  const totalHours = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60)));
  const totalDays = Math.max(1, Math.ceil(totalHours / 24));
  const dayAmount = totalDays * pricePerDay;
  const hourAmount = totalHours * pricePerHour;
  // Best pricing: choose lower of daily or hourly calculation
  const total = Math.min(dayAmount, hourAmount);
  return { hours: totalHours, days: totalDays, total };
}

export function generateBookingId(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = 'HS-';
  for (let i = 0; i < 8; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

export function generateId(prefix = 'id'): string {
  return `${prefix}-${Math.random().toString(36).substr(2, 9)}`;
}

export function validateAadhaar(aadhaar: string): boolean {
  return /^\d{12}$/.test(aadhaar);
}

export function validateMobile(mobile: string): boolean {
  return /^\d{10}$/.test(mobile);
}

export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function sanitizeInput(input: string): string {
  return input.replace(/[<>\"'&]/g, '');
}

export function clamp(num: number, min: number, max: number): number {
  return Math.min(Math.max(num, min), max);
}

export function classNames(...classes: (string | boolean | undefined)[]): string {
  return classes.filter(Boolean).join(' ');
}
