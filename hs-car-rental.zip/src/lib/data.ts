import type { AppState, Car, User, Booking, Review, ContactMessage, Notification, CmsSettings, WebsiteSettings } from './types';

export const initialCms: CmsSettings = {
  websiteName: 'HS CAR RENTAL',
  logo: '/favicon.svg',
  favicon: '/favicon.svg',
  heroTitle: 'Drive Your Dreams',
  heroSubtitle: 'Premium luxury cars for rent across India. Hourly & daily rentals with doorstep delivery.',
  heroBanner: 'https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=1600&q=80',
  aboutContent: `HS CAR RENTAL is India's premium car rental service offering a fleet of luxury, SUV, sedan and hatchback vehicles. Founded with a vision to make premium mobility accessible, we provide well-maintained cars with transparent pricing, 24/7 support and hassle-free bookings.

Whether you need a car for a business trip, wedding, airport transfer or a weekend getaway, HS CAR RENTAL ensures a smooth and luxurious experience.`,
  contactContent: 'Have questions? Our support team is available 24/7. Fill out the form below or reach us directly through phone, WhatsApp or email.',
  footerText: '© 2025 HS CAR RENTAL. All rights reserved. Premium car rental service in India.',
  termsContent: 'Terms and Conditions content goes here. By using our service you agree to our rental terms, driver eligibility criteria and payment policies.',
  privacyContent: 'Privacy Policy content goes here. We protect your personal information and use it only for booking and service purposes.',
  refundContent: 'Refund Policy content goes here. Cancellations made 24 hours before pickup are eligible for full refund minus processing charges.',
  primaryColor: '#D4AF37',
  secondaryColor: '#0a0a0a',
};

export const initialWebsite: WebsiteSettings = {
  officeAddress: 'HS CAR RENTAL, 123 MG Road, Bangalore, Karnataka 560001, India',
  contactNumber: '+91 98765 43210',
  whatsappNumber: '+91 98765 43210',
  email: 'info@hscarrental.com',
  facebook: 'https://facebook.com/hscarrental',
  instagram: 'https://instagram.com/hscarrental',
  twitter: 'https://twitter.com/hscarrental',
  youtube: 'https://youtube.com/hscarrental',
  googleMaps: 'https://maps.google.com/?q=Bangalore',
  upiId: 'hscarrental@upi',
  qrCode: '',
  codEnabled: true,
};

export const initialUsers: User[] = [
  {
    id: 'admin-1',
    fullName: 'HS Admin',
    email: 'admin@hscarrental.com',
    mobile: '9876543210',
    password: '$2a$10$hashed', // placeholder, overridden at runtime
    address: 'HS Office',
    city: 'Bangalore',
    state: 'Karnataka',
    pincode: '560001',
    role: 'admin',
    createdAt: new Date().toISOString(),
  },
];

export const initialCars: Car[] = [
  {
    id: 'car-1',
    name: 'Mercedes-Benz C-Class',
    brand: 'Mercedes',
    model: 'C-Class',
    registrationNo: 'KA-01-HS-0001',
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seatingCapacity: 5,
    pricePerHour: 1200,
    pricePerDay: 8000,
    securityDeposit: 15000,
    description: 'Experience luxury with the Mercedes-Benz C-Class. Premium interiors, smooth automatic transmission and advanced safety features make every journey memorable.',
    features: ['Leather Seats', 'Sunroof', 'GPS Navigation', 'Bluetooth', 'Parking Sensors', 'Airbags'],
    images: ['https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.8,
    reviewCount: 24,
    featured: true,
    popular: true,
    latest: false,
  },
  {
    id: 'car-2',
    name: 'BMW 5 Series',
    brand: 'BMW',
    model: '5 Series',
    registrationNo: 'KA-01-HS-0002',
    fuelType: 'Diesel',
    transmission: 'Automatic',
    seatingCapacity: 5,
    pricePerHour: 1400,
    pricePerDay: 9500,
    securityDeposit: 20000,
    description: 'The BMW 5 Series combines executive comfort with sporty performance. Ideal for business travel and special occasions.',
    features: ['Cruise Control', 'Heated Seats', 'Ambient Lighting', 'Apple CarPlay', 'Reverse Camera'],
    images: ['https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.7,
    reviewCount: 18,
    featured: true,
    popular: true,
    latest: true,
  },
  {
    id: 'car-3',
    name: 'Audi A4',
    brand: 'Audi',
    model: 'A4',
    registrationNo: 'KA-01-HS-0003',
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seatingCapacity: 5,
    pricePerHour: 1100,
    pricePerDay: 7500,
    securityDeposit: 15000,
    description: 'Stylish and sophisticated, the Audi A4 offers a refined driving experience with quattro all-wheel drive technology.',
    features: ['Quattro AWD', 'Virtual Cockpit', 'Bang & Olufsen Sound', 'Wireless Charging'],
    images: ['https://images.unsplash.com/photo-1603584173870-7f23fdae1b7a?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.6,
    reviewCount: 15,
    featured: false,
    popular: true,
    latest: true,
  },
  {
    id: 'car-4',
    name: 'Toyota Innova Crysta',
    brand: 'Toyota',
    model: 'Innova Crysta',
    registrationNo: 'KA-01-HS-0004',
    fuelType: 'Diesel',
    transmission: 'Manual',
    seatingCapacity: 7,
    pricePerHour: 500,
    pricePerDay: 3500,
    securityDeposit: 8000,
    description: 'Spacious and reliable, the Innova Crysta is perfect for family trips and group travel across India.',
    features: ['7-Seater', 'AC Rear Vents', 'Touchscreen', 'Reverse Camera', 'ABS'],
    images: ['https://images.unsplash.com/photo-1563720223185-11003d516935?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.5,
    reviewCount: 32,
    featured: true,
    popular: true,
    latest: false,
  },
  {
    id: 'car-5',
    name: 'Hyundai Creta',
    brand: 'Hyundai',
    model: 'Creta',
    registrationNo: 'KA-01-HS-0005',
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seatingCapacity: 5,
    pricePerHour: 350,
    pricePerDay: 2400,
    securityDeposit: 5000,
    description: 'Compact SUV with modern features and great mileage. Perfect for city drives and highway trips.',
    features: ['Panoramic Sunroof', 'Ventilated Seats', 'Wireless Android Auto', '6 Airbags'],
    images: ['https://images.unsplash.com/photo-1605218427306-022ba6c08491?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.4,
    reviewCount: 21,
    featured: false,
    popular: true,
    latest: true,
  },
  {
    id: 'car-6',
    name: 'Mahindra Thar',
    brand: 'Mahindra',
    model: 'Thar',
    registrationNo: 'KA-01-HS-0006',
    fuelType: 'Diesel',
    transmission: 'Manual',
    seatingCapacity: 4,
    pricePerHour: 450,
    pricePerDay: 3000,
    securityDeposit: 7000,
    description: 'The iconic off-roader for adventure seekers. Take on any terrain with the rugged Mahindra Thar.',
    features: ['4x4', 'Convertible Top', 'Waterproof Interiors', 'Touchscreen', 'Hill Hold'],
    images: ['https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.7,
    reviewCount: 28,
    featured: true,
    popular: true,
    latest: false,
  },
  {
    id: 'car-7',
    name: 'Honda City',
    brand: 'Honda',
    model: 'City',
    registrationNo: 'KA-01-HS-0007',
    fuelType: 'Petrol',
    transmission: 'Manual',
    seatingCapacity: 5,
    pricePerHour: 250,
    pricePerDay: 1800,
    securityDeposit: 4000,
    description: 'Reliable sedan with premium comfort and excellent fuel efficiency. A favorite for daily commutes.',
    features: ['Sunroof', 'Cruise Control', 'Rear AC', 'Multi-angle Camera'],
    images: ['https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.3,
    reviewCount: 19,
    featured: false,
    popular: false,
    latest: true,
  },
  {
    id: 'car-8',
    name: 'Tata Nexon EV',
    brand: 'Tata',
    model: 'Nexon EV',
    registrationNo: 'KA-01-HS-0008',
    fuelType: 'Electric',
    transmission: 'Automatic',
    seatingCapacity: 5,
    pricePerHour: 300,
    pricePerDay: 2000,
    securityDeposit: 5000,
    description: 'Go green with the Tata Nexon EV. Silent, smooth and economical for urban and intercity drives.',
    features: ['Zero Emission', 'Fast Charging', 'Connected Car Tech', 'Sunroof', '6 Airbags'],
    images: ['https://images.unsplash.com/photo-1593941707882-a5bba14938c7?auto=format&fit=crop&w=800&q=80'],
    status: 'available',
    rating: 4.5,
    reviewCount: 12,
    featured: false,
    popular: false,
    latest: true,
  },
];

export const initialReviews: Review[] = [
  {
    id: 'rev-1',
    userId: 'user-1',
    userName: 'Rahul Sharma',
    rating: 5,
    comment: 'Excellent service and well-maintained cars. The booking process was seamless.',
    status: 'approved',
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  },
  {
    id: 'rev-2',
    userId: 'user-2',
    userName: 'Priya Patel',
    rating: 4,
    comment: 'Great experience with the Mercedes. Staff was polite and professional.',
    status: 'approved',
    createdAt: new Date(Date.now() - 86400000 * 12).toISOString(),
  },
  {
    id: 'rev-3',
    userId: 'user-3',
    userName: 'Amit Kumar',
    rating: 5,
    comment: 'Best car rental in Bangalore. Transparent pricing and no hidden charges.',
    status: 'approved',
    createdAt: new Date(Date.now() - 86400000 * 20).toISOString(),
  },
];

export const initialNotifications: Notification[] = [];
export const initialBookings: Booking[] = [];
export const initialContactMessages: ContactMessage[] = [];

const STORAGE_KEY = 'hscarrental_state';

export function getInitialState(): AppState {
  return {
    cars: initialCars,
    users: initialUsers,
    bookings: initialBookings,
    reviews: initialReviews,
    contactMessages: initialContactMessages,
    notifications: initialNotifications,
    cms: initialCms,
    website: initialWebsite,
    currentUser: null,
  };
}

export function loadState(): AppState {
  if (typeof window === 'undefined') return getInitialState();
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return getInitialState();
  try {
    const parsed = JSON.parse(raw) as AppState;
    // Ensure new fields exist
    return { ...getInitialState(), ...parsed };
  } catch {
    return getInitialState();
  }
}

export function saveState(state: AppState) {
  if (typeof window === 'undefined') return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

export function clearState() {
  if (typeof window === 'undefined') return;
  localStorage.removeItem(STORAGE_KEY);
}
