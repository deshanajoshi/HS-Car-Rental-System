import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { AppState, User, Car, Booking, Review, ContactMessage, Notification, CmsSettings, WebsiteSettings } from './types';
import { loadState, saveState, getInitialState } from './data';

interface AppContextType {
  state: AppState;
  setState: React.Dispatch<React.SetStateAction<AppState>>;
  login: (email: string, password: string) => User | null;
  register: (user: Omit<User, 'id' | 'role' | 'createdAt'>) => boolean;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
  addBooking: (booking: Omit<Booking, 'id' | 'createdAt'> & { id?: string }) => Booking;
  updateBooking: (id: string, updates: Partial<Booking>) => void;
  addReview: (review: Omit<Review, 'id' | 'createdAt' | 'status'>) => void;
  addContactMessage: (msg: Omit<ContactMessage, 'id' | 'createdAt'>) => void;
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => void;
  markNotificationRead: (id: string) => void;
  updateCms: (cms: Partial<CmsSettings>) => void;
  updateWebsite: (ws: Partial<WebsiteSettings>) => void;
  addCar: (car: Omit<Car, 'id' | 'rating' | 'reviewCount'>) => void;
  updateCar: (id: string, car: Partial<Car>) => void;
  deleteCar: (id: string) => void;
  approveReview: (id: string) => void;
  hideReview: (id: string) => void;
  deleteReview: (id: string) => void;
  deleteContactMessage: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(getInitialState());
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const saved = loadState();
    // Ensure admin password is simple for demo
    const adminIndex = saved.users.findIndex((u) => u.email === 'admin@hscarrental.com');
    if (adminIndex >= 0) {
      saved.users[adminIndex].password = 'admin123';
    }
    setState(saved);
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (loaded) {
      saveState(state);
    }
  }, [state, loaded]);

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--primary', state.cms.primaryColor);
    root.style.setProperty('--secondary', state.cms.secondaryColor);
  }, [state.cms.primaryColor, state.cms.secondaryColor]);

  const login = (email: string, password: string): User | null => {
    const user = state.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!user) return null;
    // Simple plaintext comparison for demo (in production use bcrypt)
    if (user.password !== password) return null;
    const updatedState = { ...state, currentUser: user };
    setState(updatedState);
    return user;
  };

  const register = (userData: Omit<User, 'id' | 'role' | 'createdAt'>): boolean => {
    if (state.users.some((u) => u.email.toLowerCase() === userData.email.toLowerCase())) {
      return false;
    }
    const newUser: User = {
      ...userData,
      id: `user-${Date.now()}`,
      role: 'user',
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({ ...prev, users: [...prev.users, newUser], currentUser: newUser }));
    return true;
  };

  const logout = () => {
    setState((prev) => ({ ...prev, currentUser: null }));
  };

  const updateUser = (updates: Partial<User>) => {
    if (!state.currentUser) return;
    const updated = { ...state.currentUser, ...updates };
    setState((prev) => ({
      ...prev,
      currentUser: updated,
      users: prev.users.map((u) => (u.id === updated.id ? updated : u)),
    }));
  };

  const addBooking = (bookingData: Omit<Booking, 'id' | 'createdAt'> & { id?: string }): Booking => {
    const newBooking: Booking = {
      ...bookingData,
      id: bookingData.id || `booking-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({ ...prev, bookings: [newBooking, ...prev.bookings] }));
    return newBooking;
  };

  const updateBooking = (id: string, updates: Partial<Booking>) => {
    setState((prev) => ({
      ...prev,
      bookings: prev.bookings.map((b) => (b.id === id ? { ...b, ...updates } : b)),
    }));
  };

  const addReview = (reviewData: Omit<Review, 'id' | 'createdAt' | 'status'>) => {
    const newReview: Review = {
      ...reviewData,
      id: `rev-${Date.now()}`,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({ ...prev, reviews: [newReview, ...prev.reviews] }));
  };

  const addContactMessage = (msg: Omit<ContactMessage, 'id' | 'createdAt'>) => {
    const newMsg: ContactMessage = {
      ...msg,
      id: `msg-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({ ...prev, contactMessages: [newMsg, ...prev.contactMessages] }));
  };

  const addNotification = (notification: Omit<Notification, 'id' | 'createdAt'>) => {
    const newNotification: Notification = {
      ...notification,
      id: `notif-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setState((prev) => ({ ...prev, notifications: [newNotification, ...prev.notifications] }));
  };

  const markNotificationRead = (id: string) => {
    setState((prev) => ({
      ...prev,
      notifications: prev.notifications.map((n) => (n.id === id ? { ...n, read: true } : n)),
    }));
  };

  const updateCms = (cms: Partial<CmsSettings>) => {
    setState((prev) => ({ ...prev, cms: { ...prev.cms, ...cms } }));
  };

  const updateWebsite = (ws: Partial<WebsiteSettings>) => {
    setState((prev) => ({ ...prev, website: { ...prev.website, ...ws } }));
  };

  const addCar = (carData: Omit<Car, 'id' | 'rating' | 'reviewCount'>) => {
    const newCar: Car = {
      ...carData,
      id: `car-${Date.now()}`,
      rating: 0,
      reviewCount: 0,
    };
    setState((prev) => ({ ...prev, cars: [newCar, ...prev.cars] }));
  };

  const updateCar = (id: string, car: Partial<Car>) => {
    setState((prev) => ({
      ...prev,
      cars: prev.cars.map((c) => (c.id === id ? { ...c, ...car } : c)),
    }));
  };

  const deleteCar = (id: string) => {
    setState((prev) => ({ ...prev, cars: prev.cars.filter((c) => c.id !== id) }));
  };

  const approveReview = (id: string) => {
    setState((prev) => ({
      ...prev,
      reviews: prev.reviews.map((r) => (r.id === id ? { ...r, status: 'approved' as const } : r)),
    }));
  };

  const hideReview = (id: string) => {
    setState((prev) => ({
      ...prev,
      reviews: prev.reviews.map((r) => (r.id === id ? { ...r, status: 'hidden' as const } : r)),
    }));
  };

  const deleteReview = (id: string) => {
    setState((prev) => ({ ...prev, reviews: prev.reviews.filter((r) => r.id !== id) }));
  };

  const deleteContactMessage = (id: string) => {
    setState((prev) => ({ ...prev, contactMessages: prev.contactMessages.filter((m) => m.id !== id) }));
  };

  return (
    <AppContext.Provider
      value={{
        state,
        setState,
        login,
        register,
        logout,
        updateUser,
        addBooking,
        updateBooking,
        addReview,
        addContactMessage,
        addNotification,
        markNotificationRead,
        updateCms,
        updateWebsite,
        addCar,
        updateCar,
        deleteCar,
        approveReview,
        hideReview,
        deleteReview,
        deleteContactMessage,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
