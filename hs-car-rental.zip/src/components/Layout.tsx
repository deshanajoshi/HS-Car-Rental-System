import { useState, useEffect } from 'react';
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { Menu, X, Phone, Mail, MapPin, Facebook, Instagram, Twitter, Youtube, User, LogOut, Bell, Shield } from 'lucide-react';
import { useApp } from '../lib/context';
import { formatCurrency } from '../lib/utils';

export default function Layout() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const { state, logout, markNotificationRead } = useApp();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setMenuOpen(false);
  }, [location.pathname]);

  const unreadCount = state.notifications.filter((n) => !n.read).length;

  const navLinks = [
    { name: 'Home', href: '/' },
    { name: 'Cars', href: '/cars' },
    { name: 'About', href: '/about' },
    { name: 'Contact', href: '/contact' },
  ];

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0a0a]">
      {/* Top bar */}
      <div className="bg-[#0a0a0a] border-b border-[var(--primary)]/20 text-xs py-2 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center gap-6 text-gray-400">
            <span className="flex items-center gap-1"><Phone size={12} className="text-[var(--primary)]" /> {state.website.contactNumber}</span>
            <span className="flex items-center gap-1"><Mail size={12} className="text-[var(--primary)]" /> {state.website.email}</span>
            <span className="flex items-center gap-1"><MapPin size={12} className="text-[var(--primary)]" /> {state.website.officeAddress.split(',')[1]?.trim()}</span>
          </div>
          <div className="flex items-center gap-4">
            {state.website.facebook && <a href={state.website.facebook} target="_blank" rel="noreferrer" className="text-gray-400 hover:text-[var(--primary)]"><Facebook size={14} /></a>}
            {state.website.instagram && <a href={state.website.instagram} target="_blank" rel="noreferrer" className="text-gray-400 hover:text-[var(--primary)]"><Instagram size={14} /></a>}
            {state.website.twitter && <a href={state.website.twitter} target="_blank" rel="noreferrer" className="text-gray-400 hover:text-[var(--primary)]"><Twitter size={14} /></a>}
            {state.website.youtube && <a href={state.website.youtube} target="_blank" rel="noreferrer" className="text-gray-400 hover:text-[var(--primary)]"><Youtube size={14} /></a>}
          </div>
        </div>
      </div>

      {/* Navbar */}
      <nav className={`sticky top-0 z-40 transition-all duration-300 ${scrolled ? 'bg-[#0a0a0a]/95 backdrop-blur-md shadow-lg border-b border-[var(--primary)]/20' : 'bg-[#0a0a0a]'}`}>
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <Link to="/" className="flex items-center gap-3">
            <img src={state.cms.logo} alt="HS CAR RENTAL" className="h-10 w-10" />
            <div>
              <h1 className="text-xl font-bold tracking-wider text-white">HS <span className="text-[var(--primary)]">CAR</span> RENTAL</h1>
              <p className="text-[10px] text-gray-400 tracking-widest">PREMIUM MOBILITY</p>
            </div>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className={`text-sm font-medium transition-colors ${location.pathname === link.href ? 'text-[var(--primary)]' : 'text-gray-300 hover:text-[var(--primary)]'}`}
              >
                {link.name}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            {state.currentUser ? (
              <>
                <div className="relative">
                  <button onClick={() => setNotifOpen(!notifOpen)} className="relative p-2 text-gray-300 hover:text-[var(--primary)]">
                    <Bell size={20} />
                    {unreadCount > 0 && (
                      <span className="absolute top-0 right-0 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">{unreadCount}</span>
                    )}
                  </button>
                  {notifOpen && (
                    <div className="absolute right-0 mt-2 w-80 bg-[#121212] border border-[var(--primary)]/30 rounded-lg shadow-xl z-50">
                      <div className="p-3 border-b border-[var(--primary)]/20 flex justify-between items-center">
                        <span className="font-semibold text-sm">Notifications</span>
                        <button onClick={() => setNotifOpen(false)} className="text-gray-400 hover:text-white"><X size={14} /></button>
                      </div>
                      <div className="max-h-64 overflow-y-auto">
                        {state.notifications.length === 0 ? (
                          <p className="p-4 text-sm text-gray-500 text-center">No notifications</p>
                        ) : (
                          state.notifications.slice(0, 20).map((n) => (
                            <div
                              key={n.id}
                              onClick={() => { markNotificationRead(n.id); setNotifOpen(false); }}
                              className={`p-3 border-b border-[var(--primary)]/10 cursor-pointer hover:bg-[#1f1f1f] ${n.read ? 'opacity-60' : ''}`}
                            >
                              <p className="text-xs font-semibold text-[var(--primary)]">{n.title}</p>
                              <p className="text-xs text-gray-300 mt-0.5">{n.message}</p>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
                <Link to={state.currentUser.role === 'admin' ? '/admin' : '/dashboard'} className="flex items-center gap-2 text-gray-300 hover:text-[var(--primary)]">
                  {state.currentUser.role === 'admin' && <Shield size={16} className="text-[var(--primary)]" />}
                  <User size={18} />
                  <span className="text-sm">{state.currentUser.fullName.split(' ')[0]}</span>
                </Link>
                <button onClick={handleLogout} className="text-gray-300 hover:text-[var(--primary)]">
                  <LogOut size={18} />
                </button>
              </>
            ) : (
              <>
                <Link to="/login" className="text-sm font-medium text-gray-300 hover:text-[var(--primary)]">Login</Link>
                <Link to="/register" className="btn-primary text-sm">Register</Link>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden text-white" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile nav */}
        {menuOpen && (
          <div className="md:hidden bg-[#121212] border-t border-[var(--primary)]/20 px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.href}
                className={`block py-2 text-sm font-medium ${location.pathname === link.href ? 'text-[var(--primary)]' : 'text-gray-300'}`}
              >
                {link.name}
              </Link>
            ))}
            {state.currentUser ? (
              <>
                <Link to={state.currentUser.role === 'admin' ? '/admin' : '/dashboard'} className="block py-2 text-sm text-[var(--primary)]">My Account</Link>
                <button onClick={handleLogout} className="block py-2 text-sm text-gray-300">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" className="block py-2 text-sm text-gray-300">Login</Link>
                <Link to="/register" className="block py-2 text-sm text-[var(--primary)]">Register</Link>
              </>
            )}
          </div>
        )}
      </nav>

      {/* Main content */}
      <main className="flex-grow">
        <Outlet />
      </main>

      {/* Footer */}
      <footer className="bg-[#0a0a0a] border-t border-[var(--primary)]/20 pt-16 pb-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <img src={state.cms.logo} alt="HS CAR RENTAL" className="h-10 w-10" />
                <h3 className="text-lg font-bold text-white">HS <span className="text-[var(--primary)]">CAR</span> RENTAL</h3>
              </div>
              <p className="text-gray-400 text-sm leading-relaxed mb-4">{state.cms.footerText}</p>
              <div className="flex gap-3">
                {state.website.facebook && <a href={state.website.facebook} target="_blank" rel="noreferrer" className="p-2 bg-[#1f1f1f] rounded-full text-gray-400 hover:text-[var(--primary)] hover:bg-[#2a2a2a]"><Facebook size={16} /></a>}
                {state.website.instagram && <a href={state.website.instagram} target="_blank" rel="noreferrer" className="p-2 bg-[#1f1f1f] rounded-full text-gray-400 hover:text-[var(--primary)] hover:bg-[#2a2a2a]"><Instagram size={16} /></a>}
                {state.website.twitter && <a href={state.website.twitter} target="_blank" rel="noreferrer" className="p-2 bg-[#1f1f1f] rounded-full text-gray-400 hover:text-[var(--primary)] hover:bg-[#2a2a2a]"><Twitter size={16} /></a>}
                {state.website.youtube && <a href={state.website.youtube} target="_blank" rel="noreferrer" className="p-2 bg-[#1f1f1f] rounded-full text-gray-400 hover:text-[var(--primary)] hover:bg-[#2a2a2a]"><Youtube size={16} /></a>}
              </div>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><Link to="/" className="hover:text-[var(--primary)]">Home</Link></li>
                <li><Link to="/cars" className="hover:text-[var(--primary)]">Car Listing</Link></li>
                <li><Link to="/about" className="hover:text-[var(--primary)]">About Us</Link></li>
                <li><Link to="/contact" className="hover:text-[var(--primary)]">Contact Us</Link></li>
                <li><Link to="/terms" className="hover:text-[var(--primary)]">Terms & Conditions</Link></li>
                <li><Link to="/privacy" className="hover:text-[var(--primary)]">Privacy Policy</Link></li>
                <li><Link to="/refund" className="hover:text-[var(--primary)]">Refund Policy</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Contact Info</h4>
              <ul className="space-y-3 text-sm text-gray-400">
                <li className="flex items-start gap-2"><MapPin size={16} className="text-[var(--primary)] mt-0.5 shrink-0" /> {state.website.officeAddress}</li>
                <li className="flex items-center gap-2"><Phone size={16} className="text-[var(--primary)] shrink-0" /> {state.website.contactNumber}</li>
                <li className="flex items-center gap-2"><Mail size={16} className="text-[var(--primary)] shrink-0" /> {state.website.email}</li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Newsletter</h4>
              <p className="text-gray-400 text-sm mb-3">Subscribe for exclusive offers and updates.</p>
              <form onSubmit={(e) => { e.preventDefault(); alert('Subscribed successfully!'); }} className="flex flex-col gap-2">
                <input type="email" placeholder="Your email" className="form-input text-sm" required />
                <button type="submit" className="btn-primary text-sm">Subscribe</button>
              </form>
            </div>
          </div>
          <div className="border-t border-[var(--primary)]/10 pt-6 text-center text-sm text-gray-500">
            {state.cms.footerText}
          </div>
        </div>
      </footer>
    </div>
  );
}
